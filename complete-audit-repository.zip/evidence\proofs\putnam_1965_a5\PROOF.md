# putnam_1965_a5

At every stage the set of integers already listed must be an interval: it starts as a singleton, and the next unused integer must be adjacent to a listed one, hence must extend the interval at its left or right endpoint. Conversely every sequence of such endpoint extensions is valid.

If the first entry is (k), exactly (k-1) left extensions and (n-k) right extensions must occur, in arbitrary order, giving \(\binom{n-1}{k-1}\) orderings. Summing over (k) gives
\[
\sum_{k=1}^n\binom{n-1}{k-1}=2^{n-1}.
\]
