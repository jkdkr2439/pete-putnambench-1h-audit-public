# putnam_2010_b2

The value (3) is attained by the lattice triangle with vertices ((0,0),(3,0),(0,4)). A lattice segment of integer length (1) can be sent by lattice symmetries to the segment from ((0,0)) to ((1,0)). For a third point ((u,v)), its two integer distances differ by less than (1), hence are equal; then (u=1/2), impossible.

For length (2), similarly use endpoints ((0,0),(2,0)). The two integer distances differ by less than (2). Their squared difference is (4(u-1)), divisible by (4), so their difference cannot be (1); they are equal and (u=1). But \(v^2+1\) is strictly between (v^2) and ((|v|+1)^2) for nonzero integer (v), so it cannot be a square. Thus lengths (1,2) are impossible and the minimum is (3).
