# putnam_1981_b1

The double sum equals
\[
10n\sum_{h=1}^n h^4-18\left(\sum_{h=1}^n h^2\right)^2.
\]
Using
\[
\sum h^4=\frac{n^5}{5}+\frac{n^4}{2}+O(n^3),\qquad
\sum h^2=\frac{n^3}{3}+\frac{n^2}{2}+O(n),
\]
the expression is
\[
(2n^6+5n^5+O(n^4))-(2n^6+6n^5+O(n^4))=-n^5+O(n^4).
\]
After division by (n^5), the limit is (-1).
