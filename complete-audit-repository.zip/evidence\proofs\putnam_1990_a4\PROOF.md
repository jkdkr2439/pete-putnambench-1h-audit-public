# putnam_1990_a4

At least three punches are necessary: for any two centers, choose sufficiently large rational radii satisfying the triangle inequalities; the corresponding two circles intersect, and an intersection point is at rational distance from both centers, so it survives.

Three suffice. Choose centers (O=(0,0),A=(1,0),B=(0,\tau)) with τ transcendental. If a point (P=(x,y)) survived, its three distances would be rational. Subtracting the first two squared-distance equations makes (x) rational. Subtracting the first and third gives (2\tau y-\tau^2\in\mathbb Q), so (y=(\tau^2+q)/(2\tau)) for rational (q). Substitution into (x^2+y^2\in\mathbb Q) would give a nonzero polynomial equation over \(\mathbb Q\) for τ, impossible. Hence every point is removed by one of the three punches, and the answer is (3).
