# putnam_1968_a1

Polynomial division gives
\[
\frac{x^4(1-x)^4}{1+x^2}=x^6-4x^5+5x^4-4x^2+4-\frac4{1+x^2}.
\]
The integral over [0,1] of the polynomial part is
\[
\frac17-\frac46+1-\frac43+4=\frac{22}{7},
\]
while the last term integrates to (4\arctan1=\pi). Their difference is (22/7-pi), as claimed.
