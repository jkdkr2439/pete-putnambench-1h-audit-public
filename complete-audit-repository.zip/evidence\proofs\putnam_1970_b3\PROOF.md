# putnam_1970_b3

Let projected coordinates (y_j\to y), with ((x_j,y_j)\in S). The numbers (x_j) lie in the bounded interval ((a,b)), so a subsequence converges to some (x\in[a,b]). Then ((x_j,y_j)\to(x,y)); closedness of (S) puts ((x,y)in S), and the strict-strip hypothesis forces (a<x<b). Thus (y) belongs to the projection, which is closed.
