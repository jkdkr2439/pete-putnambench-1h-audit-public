# putnam_2015_b1

The differential expression factors as
\[
f+6f'+12f''+8f'''=8(D+\tfrac12)^3f
=8e^{-x/2}\frac{d^3}{dx^3}\left(e^{x/2}f(x)\right).
\]
The function (e^{x/2}f(x)) has the same five distinct real zeros as (f). Three successive applications of Rolle's theorem show that its third derivative has at least two distinct real zeros. The nonzero exponential factor does not change zeros, so the given expression also has at least two distinct real zeros.
