# putnam_2001_a1

For fixed (u), the map (L_u(v)=u*v) is injective, since applying (R_u(x)=x*u) to (L_u(v)) returns (v). Put (c=a*(b*a)). The hypothesis gives (c*a=b*a). Applying the hypothesis once with ((c,a)) and once with ((b,a)) gives
\[
(c*a)*c=a=(b*a)*b.
\]
Since (c*a=b*a=:u), this says (L_u(c)=L_u(b)). Injectivity of (L_u) yields (c=b), i.e. (a*(b*a)=b).
