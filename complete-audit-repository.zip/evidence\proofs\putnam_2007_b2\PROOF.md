# putnam_2007_b2

Put (F(t)=\int_0^t f(x)dx). Then (F(0)=F(1)=0) and |(F'')|≤(M:=\max|f'|). Linear interpolation with the Green kernel (or Taylor's theorem from both endpoints) gives
\[
|F(\alpha)|\le\frac M2\alpha(1-\alpha)\le\frac M8.
\]
Since (F(\alpha)) is the integral in the problem, this is the required bound.
