# putnam_2025_a2

The sharp classical bounds on [0,π] are
\[
\frac{x(\pi-x)}\pi\le\sin x\le\frac{4x(\pi-x)}{\pi^2}.
\]
They follow, for example, by concavity comparisons on [0,π/2] and symmetry. The lower constant is forced by the limit as (x\to0), and the upper constant is forced by (x=\pi/2). Therefore
\[
a=\frac1\pi,\qquad b=\frac4{\pi^2}.
\]
