# putnam_1983_a1

The divisors of (10^{40}=2^{40}5^{40}) correspond to (41^2) exponent pairs. The divisors of (20^{30}=2^{60}5^{30}) correspond to (61\cdot31) pairs. Their intersection consists of the divisors of the gcd (2^{40}5^{30}), numbering (41\cdot31). Inclusion--exclusion gives
\[
41^2+61\cdot31-41\cdot31=2301.
\]
