# putnam_1995_b4

Let the infinite continued denominator be (y). Then (y=2207-1/y), and positivity selects
\[
y=\frac{2207+\sqrt{2207^2-4}}2=\frac{2207+987\sqrt5}{2}.
\]
With \(\phi=(1+\sqrt5)/2\), the last number is \(\phi^{16}\). Therefore its eighth root is
\[
\phi^2=\frac{3+\sqrt5}{2}.
\]
