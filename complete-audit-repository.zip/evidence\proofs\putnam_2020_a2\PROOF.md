# putnam_2020_a2

Flip a fair coin until either (k+1) heads or (k+1) tails have appeared. By symmetry, the probability that heads wins is (1/2). If heads wins and exactly (j\le k) tails preceded the final head, the probability is
\[
\binom{k+j}{j}2^{-(k+j+1)}.
\]
Therefore
\[
\sum_{j=0}^k\binom{k+j}{j}2^{-(k+j+1)}=\frac12.
\]
Multiplication by (2^{2k+1}) gives exactly
\[
\sum_{j=0}^k2^{k-j}\binom{k+j}{j}=2^{2k}=4^k.
\]
