# putnam_1969_a1

The possible ranges are
\[
\{a\},\quad\mathbb R,\quad[a,\infty),\quad(a,\infty),\quad(-\infty,a],\quad(-\infty,a)
\]
for arbitrary real (a). Indeed, the continuous image of the connected plane is an interval, and every nonconstant polynomial is unbounded in absolute value along some line. Thus its interval range is unbounded on at least one side; a finite endpoint is included exactly when the corresponding extremum is attained, giving only the listed forms.

They all occur. Use respectively the constant (a), (x), (a+x^2),
\[
a+x^2+(xy-1)^2,
\]
and the negatives of the last two forms (with the constant shifted to (a)). The open-half-line example is positive, never zero, has infimum zero along (x\to0,y=1/x), and is unbounded; connectedness then makes its range exactly ((0,\infty)).
