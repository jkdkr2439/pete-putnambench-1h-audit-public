# putnam_2020_a3

The positive sequence decreases to (0). Taylor expansion at zero gives
\[
\frac1{\sin^2x}-\frac1{x^2}\to\frac13.
\]
Therefore
\[
\frac1{a_n^2}-\frac1{a_{n-1}^2}\to\frac13,
\]
and Stolz--Cesàro yields (1/(na_n^2)\to1/3), i.e. (a_n^2\sim3/n). The series consequently diverges.
