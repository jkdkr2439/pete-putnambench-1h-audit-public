# putnam_2025_b2

With integrals over [0,1],
\[
x_1=\frac{\int xf}{\int f},\qquad x_2=\frac{\int xf^2}{\int f^2}.
\]
Their difference has the sign of
\[
(\int xf^2)(\int f)-(\int xf)(\int f^2)
=\frac12\iint (x-y)(f(x)-f(y))f(x)f(y)\,dx\,dy.
\]
The integrand is nonnegative and is positive off the diagonal because (f) is strictly increasing and positive except possibly at the left endpoint. Hence (x_2>x_1).
