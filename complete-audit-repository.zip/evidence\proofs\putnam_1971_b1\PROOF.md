# putnam_1971_b1

Write multiplication by juxtaposition. Setting (y=x) in the second law and using idempotence gives
\[
xz=(xz)x. \tag{1}
\]
Setting (z=y) gives
\[
(xy)y=yx. \tag{2}
\]
Apply the second law to the triple (xy,x,y). By (1) and idempotence,
\[
(xy)y=((xy)x)y=(xy)(xy)=xy.
\]
Together with (2), this proves (xy=yx). The given law now becomes
\[
(xy)z=(yz)x=x(yz),
\]
which is associativity.
