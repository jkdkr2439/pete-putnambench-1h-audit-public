# putnam_1987_b1

Let the integrand be (g(x)). The substitution (x\mapsto6-x) interchanges \(\ln(9-x)\) and \(\ln(x+3)\), so (g(x)+g(6-x)=1). The interval ([2,4]) is invariant under this substitution. Therefore twice the integral equals the interval length (2), and the integral is (1).
