# putnam_1969_a6

Let (y_n\to L) and put (e_n=x_n-L/3). Then
\[
e_n=-\frac12e_{n-1}+\frac12(y_n-L).
\]
Iterating this stable recurrence, the contribution of the initial value decays geometrically, while the convolution with the null sequence (y_n-L) tends to zero (split it into a finite head and uniformly small tail). Hence (e_n\to0), so (x_n\to L/3).
