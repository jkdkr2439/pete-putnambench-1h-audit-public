# Putnam 1962 B1 — candidate proof

For nonnegative integers `x,y`, interpret `(x+y)^(n)` as the number of ordered selections of `n` distinct objects from a disjoint union of an `x`-element set and a `y`-element set. If exactly `k` selected objects come from the first set, choose their `k` positions in `binom(n,k)` ways, fill those positions injectively in `x^(k)` ways, and fill the remaining positions injectively from the second set in `y^(n-k)` ways. Summing over `k` proves the identity for all nonnegative integers `x,y`.

For fixed `n`, both sides are polynomials in `x,y`. Their difference vanishes on every pair of nonnegative integers. Fixing any nonnegative integer `y`, it is a polynomial in `x` with infinitely many roots and is therefore zero; its coefficients as polynomials in `y` then vanish on infinitely many `y`. Hence the polynomial is identically zero, proving

`(x+y)^(n) = sum_{k=0}^n binom(n,k) x^(k)y^(n-k)`

for arbitrary `x,y`.

Status before grading: `PROOF_COMPLETE`.
