# putnam_1967_b3

First take (f) to be a step function constant on a fine partition. On each fixed subinterval, periodicity makes the average of (g(nx)) tend to \(\int_0^1g\), so the asserted limit follows by summing. Continuous (f) is uniformly approximable by such step functions; the error is bounded by the uniform approximation error times \(\int_0^1|g(nx)|dx=\int_0^1|g|\). Passing to the approximation limit proves the formula.
