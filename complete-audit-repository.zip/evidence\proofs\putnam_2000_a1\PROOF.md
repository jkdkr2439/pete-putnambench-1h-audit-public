# putnam_2000_a1

Every admissible sum of squares lies strictly between (0) and (A^2): positivity gives the lower inequality, while
\((\sum x_j)^2=\sum x_j^2+2\sum_{i<j}x_ix_j\) gives the strict upper one. Conversely, for (0<r<1), take (x_j=A(1-r)r^j). Then
\[
\sum x_j^2=A^2\frac{1-r}{1+r}.
\]
As (r) ranges over ((0,1)), this ranges over all of ((0,A^2)). Hence the possible values are precisely that open interval.
