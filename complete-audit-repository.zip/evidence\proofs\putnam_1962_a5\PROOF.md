# putnam_1962_a5

Use (k^2=k(k-1)+k) and the standard differentiated-binomial identities:
\[
\sum_k\binom nk k(k-1)=n(n-1)2^{n-2},\qquad
\sum_k\binom nk k=n2^{n-1}.
\]
Their sum is (n(n+1)2^{n-2}).
