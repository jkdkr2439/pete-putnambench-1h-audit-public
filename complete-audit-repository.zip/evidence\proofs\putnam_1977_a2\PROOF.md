# putnam_1977_a2

With all denominators nonzero and (d=a+b+c\ne0), the reciprocal equation is equivalent to
\[
(a+b+c)(ab+bc+ca)=abc.
\]
But the left side minus the right side factors as ((a+b)(b+c)(c+a)). Hence one pair sums to zero. Conversely, if (after a permutation) (b=-a), then (d=c) and both equations hold. Thus all solutions are permutations of
\[
(t,-t,u,u),\qquad t,u\in\mathbb R\setminus\{0\}.
\]
