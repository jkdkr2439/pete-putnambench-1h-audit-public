# putnam_2016_a2

After canceling \(\binom{m-1}{n-1}\), the inequality is
\[
\frac{m}{m-n+1}>\frac{m-n}{n},
\]
or (mn>(m-n)(m-n+1)). Dividing by (n^2), the boundary tends to (c=(c-1)^2). The admissible interval has upper endpoint
\[
c=\frac{3+\sqrt5}{2}.
\]
Solving the quadratic inequality (and noting integer rounding changes (M(n)) by at most one from its real upper root) yields
\[
\lim_{n\to\infty}\frac{M(n)}n=\frac{3+\sqrt5}{2}.
\]
