# putnam_2023_a1

Since every cosine factor equals (1) and has first derivative (0) at the origin, the product rule gives
\[
f_n''(0)=-\sum_{k=1}^n k^2=-\frac{n(n+1)(2n+1)}6.
\]
The sum is increasing; at (n=17) it is (1785), while at (n=18) it is (2109>2023). Therefore the smallest (n) is (18).
