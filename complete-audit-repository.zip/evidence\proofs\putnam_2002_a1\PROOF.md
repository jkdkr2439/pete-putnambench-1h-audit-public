# putnam_2002_a1

Near (x=1),
\[
\frac1{x^k-1}\sim\frac1{k(x-1)}.
\]
After (n) differentiations its leading singular part is
\[
\frac{(-1)^n n!}{k(x-1)^{n+1}}.
\]
But the stated representation has leading singular part
\[
\frac{P_n(1)}{k^{n+1}(x-1)^{n+1}}.
\]
Equating coefficients gives (P_n(1)=(-1)^n n!k^n).
