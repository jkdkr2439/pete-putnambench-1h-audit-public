# Putnam 1966 A1 — candidate proof

The sequence is `a_j=floor(j/2)`. Pairing consecutive terms gives

`f(2q)=0+1+1+...+(q-1)+(q-1)+q=q^2`,

and

`f(2q+1)=f(2q)+q=q(q+1)`.

Thus in all cases

`f(t)=floor(t^2/4)`.

Let positive integers `x>y` be given. The integers `x+y` and `x-y` have the same parity.

If both are even, their squares are divisible by four, so

`f(x+y)-f(x-y)=((x+y)^2-(x-y)^2)/4=xy`.

If both are odd, each square is congruent to `1 mod 4`; taking the two floors subtracts the same `1/4` correction from both terms. Therefore the same calculation gives

`f(x+y)-f(x-y)=((x+y)^2-(x-y)^2)/4=xy`.

Status before grading: `PROOF_COMPLETE`.
