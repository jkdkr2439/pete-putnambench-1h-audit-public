# putnam_1999_a5

On the finite-dimensional vector space (V) of polynomials of degree at most (1999), (p\mapsto\int_{-1}^1|p(x)|dx) is a norm, and (p\mapsto|p(0)|) is a continuous seminorm. All norms on a finite-dimensional vector space are equivalent, so there exists (C) with
\[
|p(0)|\le C\int_{-1}^1|p(x)|dx
\]
for every (p\in V), in particular for degree exactly (1999).
