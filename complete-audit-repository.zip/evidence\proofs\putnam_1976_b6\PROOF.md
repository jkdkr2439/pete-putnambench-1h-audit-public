# DRAFT UNCOUNTED — putnam_1976_b6

This draft was never hash-locked. Audit found that the final exclusion of an even square was missing.

The divisor sum σ((N)) is odd exactly when (N) is a square or twice a square (pair divisors, with the standard prime-factorization criterion). Here σ((N))=(2N+1) is odd. If (N=2s^2), then
\[
\sigma(N)=\sigma(2)\sigma(s^2)=3\sigma(s^2)
\]
after absorbing any factor of (2) into (s) in the prime-factor criterion, whereas (2N+1=4s^2+1) cannot be divisible by (3): that would require (s^2\equiv2\pmod3). Thus (N) is a square; since (2N+1) is odd, (N) is odd as well.
