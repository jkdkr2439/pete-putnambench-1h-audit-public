# putnam_1986_a1

Writing (t=x^2), the constraint is (t^2-13t+36\le0), hence (4\le x^2\le9). Thus (x\in[-3,-2]\cup[2,3]). Since
\[
f'(x)=3(x^2-1)>0
\]
on both intervals, their respective maxima occur at (-2) and (3). They are (f(-2)=2) and (f(3)=18), so the required maximum is (18).
