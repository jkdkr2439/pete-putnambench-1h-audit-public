# Provenance metadata

- Researcher: Kevin T.N
- Role: epistemology researcher and framework designer
- Framework name: Pete / Math Fieldmap
- Tested deployment: GPT-5.6 Sol Light in Codex Desktop, operator-designated
- Model specialization claim: none; treated as general-purpose
- Corpus size: 673
- Corpus commit: `dfb0a47a1c1ec3a10f2a9acfdf41a2043920f33c`
- Timed start: `2026-08-13T20:31:41.671254+00:00`
- Timed deadline: `2026-08-13T21:31:41.671254+00:00`
- Finalization: `2026-08-13T21:31:53.906597+00:00`

The model label is operator-supplied metadata and is not cryptographically attested by the benchmark artifacts. The source run's proof hashes and append-only event chain were rechecked before publication with zero mismatches.

