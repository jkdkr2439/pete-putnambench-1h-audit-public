# putnam_1996_b1

Let a selfish set (A) have size (k), so (k\in A). It is minimal exactly when it contains none of (1,\ldots,k-1): if (j<k) belongs to (A), choose any (j)-element subset containing (j), which is a proper selfish subset; conversely, without such a (j), no proper subset can contain its own (smaller) size. Thus (A) consists of (k) and (k-1) choices from \(\{k+1,\ldots,n\}\). The answer is
\[
\sum_{k\ge1}\binom{n-k}{k-1},
\]
with impossible binomial coefficients read as zero (equivalently (1\le k\le\lfloor(n+1)/2\rfloor)).
