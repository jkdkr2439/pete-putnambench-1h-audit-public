# DRAFT UNCOUNTED — putnam_2000_b4

This draft was never hash-locked. Audit found an invalid identification of (g(\pi-\theta)) with (g(\theta)).

Put (g(\theta)=f(\cos\theta)). The equation becomes
\[
g(2\theta)=2\cos\theta,g(\theta).
\]
Because (g(\theta)=g(2\pi-\theta)), applying the same equation at π-θ gives
\[
g(2\pi-2\theta)=-2\cos\theta,g(\pi-\theta)
=-2\cos\theta,g(\theta).
\]
But (g(2\pi-2\theta)=g(2\theta)). Hence (4\cos\theta,g(\theta)=0). This gives (g(\theta)=0) except possibly at θ=π/2, and continuity handles that point. Therefore (f=0) on [-1,1].
