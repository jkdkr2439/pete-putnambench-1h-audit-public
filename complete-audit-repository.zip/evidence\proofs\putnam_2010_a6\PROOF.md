# putnam_2010_a6

Put (r(x)=f(x+1)/f(x)\in(0,1)). Since \log (r\le r-1),
\[
\int_0^N\frac{f(x)-f(x+1)}{f(x)}dx
\ge-\int_0^N\log r(x)dx.
\]
The right side equals
\[
\int_0^1\log f(x)dx-\int_N^{N+1}\log f(x)dx,
\]
which tends to (+∞) because (f(x)\downarrow0). Thus the integral diverges.
