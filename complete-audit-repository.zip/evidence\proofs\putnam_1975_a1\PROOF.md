# putnam_1975_a1

## Claim

The two representations are equivalent.

## Proof

If
\[
n=\frac{a^2+a}{2}+\frac{b^2+b}{2},
\]
then direct expansion gives
\[
4n+1=2a^2+2a+2b^2+2b+1=(a+b+1)^2+(a-b)^2.
\]
Thus one may take
\[
x=a+b+1,\qquad y=a-b.
\]

Conversely, suppose that (4n+1=x^2+y^2).  Its left side is odd, so exactly one of (x,y) is odd.  After interchanging them if needed, assume (x+y) is odd.  Hence
\[
a=\frac{x+y-1}{2},\qquad b=\frac{x-y-1}{2}
\]
are integers.  These equations invert to (x=a+b+1), (y=a-b), so the identity above, read backwards, yields
\[
n=\frac{a^2+a}{2}+\frac{b^2+b}{2}.
\]
This proves both directions.
