# putnam_1965_b5

Split the (V) vertices into parts of sizes \(\lfloor V/2\rfloor\) and \(\lceil V/2\rceil\). The complete bipartite graph has \(\lfloor V^2/4\rfloor\) edges and no triangle. Since (E\le V^2/4) and (E) is integral, retain any (E) of its edges. The resulting graph has the required numbers of vertices and edges and remains triangle-free.
