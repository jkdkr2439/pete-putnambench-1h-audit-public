# putnam_2008_b2

Repeated integration gives
\[
F_n(1)=\frac1{(n-1)!}\int_0^1(1-t)^{n-1}\log t\,dt=-\frac{H_n}{n!}.
\]
Therefore
\[
\frac{n!F_n(1)}{\log n}=-\frac{H_n}{\log n}\to-1.
\]
