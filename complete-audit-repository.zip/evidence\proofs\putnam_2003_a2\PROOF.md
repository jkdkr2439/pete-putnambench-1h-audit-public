# putnam_2003_a2

Hölder's inequality in the two-term form gives
\[
\left((\prod a_i)^{1/n}+(\prod b_i)^{1/n}\right)^n
\le\prod_{i=1}^n(a_i+b_i).
\]
Taking nonnegative (n)-th roots proves the assertion (zeros follow by continuity).
