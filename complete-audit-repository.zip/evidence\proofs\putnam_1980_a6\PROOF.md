# putnam_1980_a6

Put (u=f'-f). Variation of constants and the endpoint data give
\[
1=f(1)=\int_0^1e^{1-t}u(t)dt,
\]
so (1\le e\int_0^1|u(t)|dt). Thus every admissible integral is at least (e^{-1}). This bound is sharp: choose continuous nonnegative (u_ε) supported increasingly close to (0), normalized by \(\int e^{1-t}u_ε=1\), and define (f_ε(x)=\int_0^xe^{x-t}u_ε(t)dt). Then (f_ε\in C) and \(\int|f_ε'-f_ε|=\int u_ε\to e^{-1}\). Hence the largest universal lower bound is (1/e).
