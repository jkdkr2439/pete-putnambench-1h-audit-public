# putnam_2023_a2

Set (R(t)=t^2p(t)-1). It is monic of degree (2n+2) and vanishes at (t=\pm1/k), (1\le k\le n). Hence
\[
R(t)=\prod_{k=1}^n\left(t^2-\frac1{k^2}\right)(t^2+ct+d).
\]
The coefficient of (t) in (R) is zero, so (c=0). Since (R(0)=-1), and (n) is even, (d=-(n!)^2). Its two remaining roots are (t=\pm n!). Returning to (t=1/x), the other real values are
\[
x=\pm\frac1{n!}.
\]
