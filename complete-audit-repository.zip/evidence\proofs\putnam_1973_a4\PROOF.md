# putnam_1973_a4

Let (F(x)=2^x-1-x^2). We have roots (0,1), and sign checks (F(4)<0<F(5)) give a third. Now
\[
F''(x)=(\log2)^2 2^x-2
\]
has exactly one zero. Hence (F') has at most two zeros and Rolle's theorem implies (F) has at most three distinct zeros. Therefore it has exactly three.
