# putnam_1973_b2

All powers of (z=x+iy) have rational real and imaginary parts. Since |(z)|=1,
\[
|z^{2n}-1|=|z^n|\,|z^n-z^{-n}|=|z^n-\overline{z^n}|=2|\operatorname{Im}(z^n)|,
\]
which is rational.
