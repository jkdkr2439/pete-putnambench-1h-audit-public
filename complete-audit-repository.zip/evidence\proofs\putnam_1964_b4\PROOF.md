# putnam_1964_b4

Let (R_n) be the number of regions. The (n)-th great circle meets the preceding (n-1) circles in (2(n-1)) distinct points, which divide it into (2(n-1)) arcs. Each arc splits one old region, so (R_n=R_{n-1}+2(n-1)). Since (R_1=2),
\[
R_n=2+2\sum_{j=1}^{n-1}j=n^2-n+2.
\]
