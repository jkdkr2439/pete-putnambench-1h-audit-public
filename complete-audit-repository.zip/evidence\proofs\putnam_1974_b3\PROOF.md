# putnam_1974_b3

If α were rational, ζ=(e^{i\pi\alpha}) would be a root of unity and hence an algebraic integer. Then ζ+ζ⁻¹=2cos(πα)=2/3 would be both rational and an algebraic integer, hence an integer, a contradiction.
