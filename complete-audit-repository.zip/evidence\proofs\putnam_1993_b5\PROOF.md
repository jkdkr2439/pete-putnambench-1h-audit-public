# putnam_1993_b5

Reduce every point's coordinates modulo (2). An odd squared distance means the two parity vectors differ in exactly one coordinate. But the graph on \(\mathbb F_2^2\) joining vectors at Hamming distance one is a four-cycle and has no triangle. Among four points, even three would have to give three parity vectors pairwise adjacent (coincident vectors give even distance), impossible. Hence such four points do not exist.
