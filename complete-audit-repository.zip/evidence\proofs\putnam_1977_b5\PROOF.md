# putnam_1977_b5

Denote the constant in the problem by (H). Fix (i<j), put (C=a_i+a_j), (T=\sum_{k\ne i,j}a_k), and (U=\sum_{k\ne i,j}a_k^2\ge T^2/(n-2)) (the case (n=2) is immediate). Then
\[
S^2-(n-1)\sum a_k^2-2(n-1)a_ia_j
\le -(n-2)\left(C-\frac{T}{n-2}\right)^2\le0.
\]
Therefore \(S^2/(n-1)-\sum a_k^2\le2a_ia_j\). The hypothesis places (H) strictly below the left side, proving (H<2a_ia_j).
