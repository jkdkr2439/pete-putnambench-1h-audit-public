# putnam_1981_a1

Counting each factor of (5) separately,
\[
E(n)=\sum_{r\ge1}\sum_{\substack{j\le n\\5^r\mid j}}j
=\sum_{r\ge1}5^r\frac{q_r(q_r+1)}2,qquad q_r=\left\lfloor\frac n{5^r}\right\rfloor.
\]
After division by (n^2), dominated convergence over the geometric tail gives
\[
\lim\frac{E(n)}{n^2}=\frac12\sum_{r\ge1}\frac1{5^r}=\frac18.
\]
