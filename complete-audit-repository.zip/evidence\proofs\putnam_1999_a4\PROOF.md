# putnam_1999_a4

Let the summand be (T_{m,n}). Pairing it with (T_{n,m}) gives
\[
T_{m,n}+T_{n,m}=\frac{mn}{3^{m+n}}.
\]
Absolute convergence permits pairing, so the full sum is
\[
\frac12\sum_{m,n\ge1}\frac{mn}{3^{m+n}}
=\frac12\left(\sum_{m\ge1}\frac m{3^m}\right)^2
=\frac12\left(\frac34\right)^2=\frac9{32}.
\]
