# putnam_2008_b1

Three rational points on a circle are noncollinear and determine its center by two linear perpendicular-bisector equations with rational coefficients; hence their center is rational. Therefore a circle with nonrational center has at most two rational points. The bound is attained: the unit circle centered at \((1/2,\sqrt3/2)\) contains the rational points ((0,0)) and ((1,0)); a third rational point would force its center to be rational by the preceding argument. The maximum is (2).
