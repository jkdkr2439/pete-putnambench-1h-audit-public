# putnam_2009_b1

We first prove by induction that every positive integer is a quotient of products of factorials of primes. Composite integers follow by multiplying representations of their proper factors. If (p) is prime, then
\[
p=\frac{p!}{(p-1)!};
\]
the numerator is an allowed prime factorial, while each factor of ((p-1)!) has a representation by induction, so their product does too. The base case is (1) (empty product), and (2=2!).

Finally write any positive rational as a quotient of two positive integers and substitute the representations just constructed, moving denominator factors as needed. This gives the required quotient of products of prime factorials.
