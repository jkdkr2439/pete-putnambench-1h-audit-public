# putnam_1976_b5

The displayed sum is ((-1)^n) times the (n)-th forward difference of the monic degree-(n) polynomial (t\mapsto(x-t)^n). An (n)-th finite difference equals (n!) times the leading coefficient; here that coefficient in (t) is ((-1)^n). Therefore the sum equals (n!).
