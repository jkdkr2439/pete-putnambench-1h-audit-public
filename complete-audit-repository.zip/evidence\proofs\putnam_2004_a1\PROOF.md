# putnam_2004_a1

Let (D(N)=5S(N)-4N). The hypotheses say that this integer is negative early and positive later. On a successful throw (D) increases by (1); on a miss it decreases by (4). At the first time it becomes positive after being negative, its last change must be (+1), so it must pass through (0). There (5S(N)=4N), or (S(N)=0.8N). Thus the answer is yes.
