# putnam_2003_b1

No. Regard a bivariate polynomial as its coefficient matrix, with rows indexed by powers of (x) and columns by powers of (y). The polynomial (1+xy+x^2y^2) has a (3\times3) identity coefficient submatrix and therefore rank (3). Each separated product (a(x)c(y)) is an outer product of coefficient vectors and has rank at most (1); a sum of two such products has rank at most (2), impossible.
