# putnam_2017_a3

Let (M=\int f=\int g), use probability measure (d\mu=f,dx/M), and put (R=f/g>0). Then (I_n=M\mathbb E_μR^n). Cauchy--Schwarz gives (I_1\ge M=I_0), strictly unless (f=g). The moment sequence is log-convex, so its successive ratios are nondecreasing; hence (I_n) is strictly increasing.

If the moments were bounded, then (R\le1) μ-almost everywhere (otherwise high moments diverge). But \(\mathbb E_μ(1/R)=\int g/M=1\); together with (R\le1), this forces (R=1) everywhere by continuity, contradicting (f\ne g). Thus (I_n\to\infty).
