# putnam_1978_b2

Using (1/(i+j+2)=\int_0^1x^{i+j+1}\,dx) and absolute convergence,
\[
\sum_{i,j\ge1}\frac1{ij(i+j+2)}
=\int_0^1x\left(\sum_{i\ge1}\frac{x^i}{i}\right)^2dx
=\int_0^1x\log^2(1-x)\,dx.
\]
Differentiating (B(2,a)=1/(a(a+1))) twice at (a=1) evaluates the last integral as (7/4).
