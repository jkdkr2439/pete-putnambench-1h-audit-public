# putnam_1994_a1

For every (mge0), sum the given inequality over (n=2^m,ldots,2^{m+1}-1). The children (2n,2n+1) run exactly through (2^{m+1},ldots,2^{m+2}-1), so the sum on each dyadic level is strictly positive and no larger than the sum on the next level. Hence every level sum is at least (a_1>0). The partial sums through level (M) are therefore at least ((M+1)a_1), which tends to infinity.
