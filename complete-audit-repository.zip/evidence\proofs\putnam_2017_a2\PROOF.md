# putnam_2017_a2

Let (U_n) be defined by (U_0=1,U_1=x), and (U_n=xU_{n-1}-U_{n-2}); these are integer polynomials. The standard determinant identity
\[
U_{n-1}^2-1=U_nU_{n-2}
\]
follows immediately by induction from that recurrence. Therefore the given quotient recurrence produces (Q_n=U_n) inductively. In particular every (Q_n) is a polynomial with integer coefficients.
