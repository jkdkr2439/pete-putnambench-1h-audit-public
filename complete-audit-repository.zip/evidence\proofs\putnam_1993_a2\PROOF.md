# putnam_1993_a2

Define (a_n=(x_{n+1}+x_{n-1})/x_n). Using (x_n^2-x_{n-1}x_{n+1}=1) twice,
\[
a_n-a_{n-1}
=\frac{x_{n+1}x_{n-1}-x_n^2+x_{n-1}^2-x_{n-2}x_n}{x_nx_{n-1}}=0.
\]
Thus all (a_n) equal a constant (a), and rearrangement gives (x_{n+1}=ax_n-x_{n-1}).
