# putnam_2018_a3

Put \(y_i=\cos x_i\). Since \(\sum y_i=0\), the target is \(4\sum y_i^3\). For a fixed total positive mass \(s=k+r\), where \(k=\lfloor s\rfloor\) and \(0\le r\le1\), convexity of \(y^3\) on \([0,1]\) shows that the positive contribution is at most \(k+r^3\). Concavity on \([-1,0]\) shows that the negative mass is optimally spread equally among all available negative entries.

If \(0<r<1\), there are \(9-k\) negative entries, so
\[
 \sum_i y_i^3\le F_k(r):=k+r^3-\frac{(k+r)^3}{(9-k)^2}.
\]
Moreover,
\[
 F_k'(r)=3\left(r^2-\frac{(k+r)^2}{(9-k)^2}\right).
\]
Its only interior critical point is \(r=k/(8-k)\), where the derivative changes from negative to positive. Thus no open interval \(0<r<1\) has a maximum exceeding both limiting endpoints. The limit at \(r=1\) is the next integer case. At \(r=0\), there are \(10-k\) negative entries, and the exact value is
\[
G(k)=k-\frac{k^3}{(10-k)^2}\quad(k=0,1,2,3,4,5).
\]
These values are \(0,80/81,15/8,120/49,20/9,0\), whose maximum is \(120/49\) at \(k=3\). Hence the maximizing pattern, up to permutation, is
\[
1,1,1,-\frac37,-\frac37,-\frac37,-\frac37,-\frac37,-\frac37,-\frac37.
\]
Therefore
\[
\max\sum\cos(3x_i)=4\left(3-7\left(\frac37\right)^3\right)=\frac{480}{49}.
\]
All displayed \(y_i\) lie in \([-1,1]\) and hence are cosines of real angles, so equality is attainable.
