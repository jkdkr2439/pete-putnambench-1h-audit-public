# putnam_1969_b6

For the displayed matrix (C=AB), direct multiplication gives (C^2=9C), and its rank is (2). Hence (A,B) both have rank (2), so the (2\times2) matrix (BA) is invertible. Multiplying (C^2=9C) on the left by (B) and on the right by (A) gives
\[
(BA)^3=9(BA)^2.
\]
Since (BA) is invertible, cancellation yields (BA=9I_2), as required.
