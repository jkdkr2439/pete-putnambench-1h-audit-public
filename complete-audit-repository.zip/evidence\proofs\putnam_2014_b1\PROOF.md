# putnam_2014_b1

The integers with unique over-expansion are exactly those whose ordinary decimal expansion has no digit (0).

If an ordinary expansion has a zero in position (i) below a nonzero higher part, borrow once from the nearest nonzero digit to its left: the intervening zeros become (9)'s and the digit immediately below the borrowed position becomes (10). This gives a distinct allowed over-expansion.

Conversely compare an over-expansion with the ordinary one from the least significant digit upward. At the first differing digit, congruence modulo (10) forces the over-digit to be (10) and the ordinary digit to be (0); the discrepancy is precisely a carry into the next position. Thus a second expansion can exist only if the ordinary expansion contains a zero. This proves the classification.
