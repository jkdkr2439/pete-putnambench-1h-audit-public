# putnam_1981_b2

Put
\[
u_1=r-1, u_2=s/r-1, u_3=t/s-1, u_4=4/t-1.
\]
They are nonnegative and \(\prod(1+u_i)=4\). Convexity (or Lagrange multipliers followed by smoothing) shows that \(\sum u_i^2\) under this product constraint is minimized when all (u_i) are equal. Thus (u_i=4^{1/4}-1=\sqrt2-1), and the minimum is
\[
4(\sqrt2-1)^2.
\]
It is attained at (r=\sqrt2,s=2,t=2\sqrt2).
