# putnam_1986_a2

Put (X=10^{100}). Polynomial division gives
\[
\frac{X^{200}}{X+3}=X^{199}-3X^{198}+\cdots+(-3)^{199}+\frac{3^{200}}{X+3}.
\]
Because (0<3^{200}<10^{100}<X+3), the floor is the integer polynomial part. All terms except its constant term are divisible by (10), so its units digit is that of ((-3)^{199}). Since (3^{199}\equiv7\pmod{10}), the required digit is (3).
