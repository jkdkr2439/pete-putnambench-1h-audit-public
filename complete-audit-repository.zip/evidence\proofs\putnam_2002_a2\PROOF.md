# putnam_2002_a2

Choose two of the five points and a plane through the sphere's center containing them. The plane bounds two closed hemispheres, and both chosen points lie in both. Of the remaining three points, at least two lie in the same one of the two closed hemispheres. That hemisphere therefore contains the chosen pair and those two points, hence at least four of the five.
