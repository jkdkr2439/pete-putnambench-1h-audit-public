# putnam_1979_b2

For small (t), \(\log\int_0^1u(x)^t dx=t\int_0^1\log u(x)dx+o(t)\), where (u(x)=a+(b-a)x). Hence the logarithm of the limit is
\[
\int_0^1\log(a+(b-a)x)dx
=\frac{b\log b-a\log a}{b-a}-1.
\]
The limit is therefore
\[
\exp\left(\frac{b\log b-a\log a}{b-a}-1\right).
\]
