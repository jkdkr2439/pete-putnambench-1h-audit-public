# putnam_1974_b6

With ω a primitive cube root of unity, the roots-of-unity filter gives
\[
N_r=\frac13\left(2^{1000}+2\Re(\omega^{-r}(1+\omega)^{1000})\right).
\]
Since (1+ω=e^{i\pi/3}) and (1000\equiv4\pmod6), its 1000th power is ω². Therefore
\[
N_0=N_1=\frac{2^{1000}-1}{3},\qquad N_2=\frac{2^{1000}+2}{3}.
\]
