# putnam_2003_a3

Put (t=\sin x+\cos x\in[-\sqrt2,\sqrt2]). Wherever the expression is defined, \(\sin x\cos x=(t^2-1)/2\), so it equals
\[
t+\frac{1+t}{\sin x\cos x}=t+\frac2{t-1}.
\]
Elementary one-variable calculus on the allowed interval (excluding (t=\pm1)) shows the least absolute value occurs at (t=1-\sqrt2), where it is
\[
|1-2\sqrt2|=2\sqrt2-1.
\]
Every (t\in[-\sqrt2,\sqrt2]) is attained by some (x), and this particular (t) does not make a denominator zero, so the minimum is attained.
