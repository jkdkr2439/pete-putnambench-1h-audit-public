# putnam_2014_a1

For (n\ge2), the coefficient of (x^n) is
\[
\frac1{n!}-\frac1{(n-1)!}+\frac1{(n-2)!}=\frac{(n-1)^2}{n!}.
\]
Put (m=n-1). Cancelling the factor (m) already present in (n!) leaves
\[
\frac{m}{(m+1)(m-1)!}.
\]
If (m=p) is prime, its reduced numerator is (p). If (m) is composite and (m\ne4), the elementary factorial divisibility (m\mid(m-1)!) makes the reduced numerator (1); for the exceptional case (m=4), it is (2). Thus every nonzero reduced numerator is (1) or a prime. The constant coefficient is (1), while the linear coefficient is zero.
