# putnam_2019_b3

Since (Q-I) is invertible, the matrix determinant lemma gives
\[
\det(PQ-I)=\det(Q-I)\left(1-2u^TQ(Q-I)^{-1}u\right).
\]
Orthogonality shows that the symmetric part of (Q(Q-I)^{-1}) is (I/2) (transpose it, use (Q^T=Q^{-1}), and simplify). Hence the scalar in parentheses is (1-2(1/2)u^Tu=0). Thus (PQ-I) is singular, so (1) is an eigenvalue of (PQ).
