# putnam_1969_b2

If (G=H\cup K) with both subgroups proper, neither can contain the other. Choose (h\in H\setminus K) and (k\in K\setminus H). Then (hk\notin H) (else (k=h^{-1}hk\in H)) and (hk\notin K) (else (h=hkk^{-1}\in K)), contradiction.

With three subgroups the statement is false: the Klein four group is the union of its three subgroups of order two.
