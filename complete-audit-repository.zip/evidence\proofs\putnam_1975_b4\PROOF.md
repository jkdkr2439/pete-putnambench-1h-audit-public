# putnam_1975_b4

No. If such a closed (B) existed, its antipodal image (-B) would also be closed. Selecting exactly one point from each antipodal pair says (C=B\sqcup(-B)). Hence (B) would have closed complement and would be both open and closed. Both pieces are nonempty, contradicting connectedness of the circle.
