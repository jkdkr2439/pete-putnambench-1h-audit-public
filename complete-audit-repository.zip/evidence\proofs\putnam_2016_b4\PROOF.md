# putnam_2016_b4

For (i<j), put (Y_{ij}=A_{ij}-A_{ji}). These variables are independent, have mean (0), and satisfy \(\mathbb E Y_{ij}^2=1/2\). Since (A-A^T) is skew-symmetric of even size,
\[
\det(A-A^T)=\operatorname{Pf}(A-A^T)^2.
\]
Expand the Pfaffian as a signed sum over perfect matchings. In the expected square, a cross term from two different matchings contains some (Y_{ij}) to the first power and hence has expectation zero. Each diagonal term contributes ((1/2)^n). There are
\[
(2n-1)!!=\frac{(2n)!}{2^n n!}
\]
perfect matchings. Therefore
\[
\mathbb E\det(A-A^T)=\frac{(2n)!}{4^n n!}.
\]
