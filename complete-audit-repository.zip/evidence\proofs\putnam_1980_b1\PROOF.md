# putnam_1980_b1

The inequality is equivalent to \(\log\cosh x\le cx^2\). Since
\[
\log\cosh x=\int_0^{|x|}\tanh t\,dt\le\int_0^{|x|}t\,dt=\frac{x^2}{2},
\]
(c=1/2) suffices, and every larger (c) also suffices. Taylor expansion \(\log\cosh x=x^2/2+O(x^4)\) shows (c\ge1/2) is necessary. Thus (c\in[1/2,\infty)).
