# putnam_2008_a1

Taking (x=y=z) gives (f(x,x)=0). Taking (z=x) then gives (f(x,y)=-f(y,x)). Finally put (z=0) in the original identity:
\[
f(x,y)+f(y,0)+f(0,x)=0.
\]
Define (g(x)=f(x,0)). Antisymmetry says (f(0,x)=-g(x)), and therefore (f(x,y)=g(x)-g(y)).
