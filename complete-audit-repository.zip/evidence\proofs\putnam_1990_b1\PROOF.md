# putnam_1990_b1

Differentiating the identity gives
\[
2ff'=f^2+(f')^2,
\]
so ((f-f')^2=0) and (f'=f). Hence (f(x)=Ce^x). At (x=0), the original equation gives (C^2=1990). Conversely (f(x)=\pm\sqrt{1990},e^x) directly satisfies the identity. These are exactly the two solutions.
