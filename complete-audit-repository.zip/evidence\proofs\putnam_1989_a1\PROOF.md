# putnam_1989_a1

With (r) ones, the number is
\[
N_r=1+100+\cdots+100^{r-1}=\frac{10^{2r}-1}{99}.
\]
If (r) is composite, the geometric sum factors nontrivially. Thus primality requires (r) prime. For every odd prime (r),
\[
N_r=\frac{10^r-1}{9}\cdot\frac{10^r+1}{11},
\]
a nontrivial factorization. The only remaining prime value of (r) is (2), which gives (101), itself prime. (For (r=1), the number is (1).) Hence there is exactly one such prime.
