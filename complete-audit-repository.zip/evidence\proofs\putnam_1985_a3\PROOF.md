# putnam_1985_a3

The recurrence satisfies (a_m(j+1)+1=(a_m(j)+1)^2), so
\[
a_n(n)=\left(1+\frac{d}{2^n}\right)^{2^n}-1.
\]
Therefore the limit is (e^d-1).
