# putnam_2001_b3

The integers whose nearest integer to the square root is (r\ge1) are
\[
r^2-r+1\le n\le r^2+r,
\]
exactly (2r) integers. Their contribution is
\[
(2^r+2^{-r})\sum_{n=r^2-r+1}^{r^2+r}2^{-n}
=2^{1-(r-1)^2}-2^{1-(r+1)^2}.
\]
Summing over (r\ge1) telescopes, leaving (2^{1-0^2}+2^{1-1^2}=2+1=3).
