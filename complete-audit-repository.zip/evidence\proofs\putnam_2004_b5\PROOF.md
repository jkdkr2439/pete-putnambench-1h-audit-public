# putnam_2004_b5

Taking logarithms and shifting one index gives
\[
L(x)=-\log2+(1-x)\sum_{m\ge1}x^{m-1}\log(1+x^m).
\]
As (x\to1^-), this is a standard Riemann-sum/Abelian limit. With (u=x^m),
\[
(1-x)\sum_{m\ge1}x^{m-1}\log(1+x^m)\longrightarrow
\int_0^1\log(1+u)\,du=2\log2-1.
\]
Hence (L(x)\to\log2-1), and the original product tends to
\[
e^{\log2-1}=\frac2e.
\]
