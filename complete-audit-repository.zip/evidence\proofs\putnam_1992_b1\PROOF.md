# putnam_1992_b1

Order (S) as (a_1<\cdots<a_n). The pair sums
\[
a_1+a_2<a_1+a_3<\cdots<a_1+a_n<a_2+a_n<\cdots<a_{n-1}+a_n
\]
give (2n-3) distinct averages, so |(A_S)| is at least (2n-3). Equality is attained by any arithmetic progression: its pair sums take exactly the (2n-3) consecutive index-sum values (3,4,\ldots,2n-1). Thus the minimum is (2n-3).
