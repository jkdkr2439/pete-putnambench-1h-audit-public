# putnam_1970_b5

If (F) is continuous, every (u_n\circ F) is continuous. Conversely, fix (x_0) and choose (n>|F(x_0)|+1). Continuity of (u_n\circ F) gives a neighborhood of (x_0) on which its value remains strictly between (-n) and (n). On that neighborhood clipping is inactive, so (F=u_n\circ F). Thus (F) is continuous at (x_0), and hence everywhere.
