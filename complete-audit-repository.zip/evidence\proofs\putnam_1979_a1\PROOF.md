# putnam_1979_a1

In a maximizing partition, no part is at least (5), since replacing (q\ge5) by (3,q-3) multiplies the product by (3(q-3)/q>1). No part (1) occurs (merge it into another part), and three (2)'s should be replaced by two (3)'s. Thus only (2)'s and (3)'s occur, with at most two (2)'s. Since (1979\equiv2\pmod3), the unique multiset is one (2) and (659) threes. Hence (n=660), in any ordering, and the maximum product is (2\cdot3^{659}).
