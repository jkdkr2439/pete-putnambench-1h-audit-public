# putnam_1966_a2

Put (x=p-a,y=p-b,z=p-c). Then (p=x+y+z) and Heron's formula gives (r^2=xyz/p). The desired inequality becomes
\[
\frac1{x^2}+\frac1{y^2}+\frac1{z^2}\ge\frac{x+y+z}{xyz},
\]
or (yz/x+zx/y+xy/z\ge x+y+z). This is Schur's inequality after clearing denominators (equivalently, order the variables and factor the resulting differences), and holds for all positive (x,y,z).
