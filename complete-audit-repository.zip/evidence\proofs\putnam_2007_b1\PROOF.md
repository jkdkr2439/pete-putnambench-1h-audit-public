# putnam_2007_b1

Modulo (f(n)), the congruence (f(n)+1\equiv1) implies
\[
f(f(n)+1)\equiv f(1)\pmod{f(n)}.
\]
Thus divisibility is equivalent to (f(n)\mid f(1)). Positive coefficients and nonconstancy make (f(n)\ge f(1)), with equality only at (n=1). Therefore the divisibility holds exactly when (n=1).
