# putnam_1962_a4

Fix (x) and choose a length-two subinterval [a,b] of the given interval containing (x). Put (u=x-a,v=b-x), so (u+v=2). Taylor's formula with integral remainder at both endpoints, followed by elimination of (f(x)), gives
\[
\left|f'(x)-\frac{f(b)-f(a)}2\right|\le\frac{u^2+v^2}{4}.
\]
Hence
\[
|f'(x)|\le1+\frac{u^2+v^2}{4}\le1+\frac{(u+v)^2}{4}=2.
\]
