# putnam_2005_a4

Sum the (a) rows participating in the all-one submatrix. On its (b) specified coordinates the sum equals (a), so the squared norm of the sum is at least (a^2b). The rows are mutually orthogonal and each has squared norm (n), so the same squared norm equals (an). Hence (a^2b\le an), or (ab\le n).
