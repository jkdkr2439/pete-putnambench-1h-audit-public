# putnam_1992_a4

Let (g(x)=1/(1+x^2)). The smooth function (h=f-g) vanishes at every (1/n), a sequence tending to (0). Repeated Rolle's theorem shows successively that every derivative (h^{(k)}(0)=0). Thus (f) and (g) have the same derivatives at zero. From
\[
g(x)=\sum_{j\ge0}(-1)^j x^{2j}
\]
near zero, we obtain
\[
f^{(2j+1)}(0)=0,qquad f^{(2j)}(0)=(-1)^j(2j)!.
\]
