# putnam_2001_b1

The entry in row (i), column (j) is ((i-1)n+j). In each row, equal red and black counts make the contribution of the row-offset ((i-1)n) cancel in the red-minus-black sum. In each column, equal counts likewise make the column label (j) cancel. Summing these two cancellations over all cells shows that the red-minus-black total is zero.
