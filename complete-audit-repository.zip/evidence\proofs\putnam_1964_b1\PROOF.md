# putnam_1964_b1

Interpret (b_n=\#\{j:a_j\le n\}). Fix ε>0. Choose (J) so that \(\sum_{j>J}1/a_j<\varepsilon\). Among indices (j>J) with (a_j\le n), every summand (1/a_j\) is at least (1/n); hence their number is at most (n\varepsilon). The remaining qualifying indices number at most (J). Therefore
\[
0\le \frac{b_n}{n}\le \frac Jn+\varepsilon.
\]
Taking the limsup and then letting ε tend to zero proves (b_n/n\to0).
