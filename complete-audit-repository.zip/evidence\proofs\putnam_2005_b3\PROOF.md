# putnam_2005_b3

Replacing (x) by (a/x) in the equation gives
\[
f'(x)=\frac{a}{x f(a/x)}.
\]
Consequently the derivative of (f(x)f(a/x)) is zero; write this positive constant as (C). Then
\[
\frac{f'(x)}{f(x)}=\frac{a}{Cx},
\]
so (f(x)=Kx^r), where (r=a/C>0). Substitution gives the single condition
\[
K^2=\frac{a^{1-r}}r.
\]
Thus, for arbitrary (r>0), all solutions are
\[
f(x)=\frac{a^{(1-r)/2}}{\sqrt r},x^r,
\]
and direct substitution verifies them.
