# putnam_2006_b6

Let (b_n=a_n^{(k+1)/k}). By the mean value theorem and (a_n\to\infty),
\[
b_{n+1}-b_n=\frac{k+1}{k}\xi_n^{1/k}(a_{n+1}-a_n)
=\frac{k+1}{k}\left(\frac{\xi_n}{a_n}\right)^{1/k}\to\frac{k+1}{k},
\]
because (a_{n+1}/a_n\to1). Stolz--Cesàro gives (b_n/n\to(k+1)/k). Hence
\[
\frac{a_n^{k+1}}{n^k}=\left(\frac{b_n}{n}\right)^k\to\left(\frac{k+1}{k}\right)^k.
\]
