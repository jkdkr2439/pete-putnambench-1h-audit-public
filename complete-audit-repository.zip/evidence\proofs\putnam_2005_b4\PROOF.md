# putnam_2005_b4

Choose the (j) nonzero coordinates, their signs, and their positive absolute values. For fixed (j\ge1), stars and bars gives \(\binom nj2^j\binom mj\) vectors with \(\sum|x_i|\le m\); include (j=0). Thus
\[
f(m,n)=\sum_{j\ge0}2^j\binom nj\binom mj,
\]
which is symmetric in (m,n). Hence (f(m,n)=f(n,m)).
