# putnam_1974_a4

The identity
\[
(n-2k)\binom nk=n\left(\binom{n-1}k-\binom{n-1}{k-1}\right)
\]
makes the sum telescope. With (m=\lfloor(n-1)/2\rfloor), the condition (k<n/2) is (0\le k\le m), so the requested value is
\[
\frac{n}{2^{n-1}}\binom{n-1}{\lfloor(n-1)/2\rfloor}.
\]
