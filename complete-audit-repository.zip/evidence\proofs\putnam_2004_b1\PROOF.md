# putnam_2004_b1

Write (r=p/q) in lowest terms. By Gauss's lemma, the primitive linear polynomial (qx-p) divides (P(x)) in \(\mathbb Z[x]\): say (P=(qx-p)Q) with (Q\in\mathbb Z[x]). Dividing instead by (x-r) gives (P=(x-r)(qQ)), so every coefficient of the synthetic quotient is divisible by (q). The listed (j)-th number is (r) times the corresponding synthetic-quotient coefficient. It is therefore (p/q) times a multiple of (q), hence an integer.
