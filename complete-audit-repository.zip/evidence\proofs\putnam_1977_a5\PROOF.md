# putnam_1977_a5

In \(\mathbb F_p[X]\), the freshman's dream gives
\[
(1+X)^{pm}=((1+X)^p)^m=(1+X^p)^m.
\]
Comparing coefficients of (X^{pn}) yields \(\binom{pm}{pn}\equiv\binom mn\pmod p\).
