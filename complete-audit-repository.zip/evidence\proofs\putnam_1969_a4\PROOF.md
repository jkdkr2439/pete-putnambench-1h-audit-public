# putnam_1969_a4

On ((0,1]), expand (x^x=e^{x\log x}). Dominated termwise integration (or first on [δ,1] and then δ↓0) gives
\[
\int_0^1x^x dx=\sum_{m=0}^\infty\frac1{m!}\int_0^1x^m(\log x)^m dx.
\]
The integral is \((-1)^m m!/(m+1)^{m+1}\), so reindexing (n=m+1) yields
\[
\sum_{n=1}^\infty(-1)^{n+1}n^{-n}.
\]
