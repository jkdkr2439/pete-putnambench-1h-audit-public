# putnam_2003_b3

Compare valuations at a prime (p). On the right, (p) occurs in \(\operatorname{lcm}(1,\ldots,\lfloor n/i\rfloor)\) once for every exponent (a\ge1) with (p^a\le n/i). Thus its total exponent is
\[
\sum_{a\ge1}\#\{i:i p^a\le n\}=\sum_{a\ge1}\left\lfloor\frac n{p^a}\right\rfloor=v_p(n!).
\]
All prime valuations agree, proving the identity.
