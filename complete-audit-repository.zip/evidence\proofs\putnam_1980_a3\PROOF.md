# putnam_1980_a3

Let the integrand be (g(x)). Under (x\mapsto\pi/2-x), the tangent is replaced by its reciprocal, so (g(x)+g(\pi/2-x)=1). Therefore twice the integral is π/2, and its value is π/4.
