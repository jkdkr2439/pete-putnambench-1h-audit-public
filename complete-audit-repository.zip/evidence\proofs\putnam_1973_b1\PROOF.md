# putnam_1973_b1

Let (S=\sum_i a_i). Removing (a_i) leaves two equal integer sums, so (S-a_i) is even. Hence all (a_i) have the same parity.

If they were not all equal, choose that common parity (c\in\{0,1\}) and replace every (a_i) by ((a_i-c)/2). The new integers retain the hypothesis, because every equality of sums has the same number (n) of terms on each side. But their range (maximum minus minimum) is half the old positive integer range. Repeating produces an infinite strictly decreasing sequence of positive integer ranges, impossible. Therefore the original integers are all equal.
