# putnam_1971_a3

The area Δ of a nondegenerate lattice triangle is a positive half-integer, so Δ≥1/2. The circumradius identity (abc=4R\Delta) therefore gives
\[
abc\ge4R\cdot\frac12=2R.
\]
