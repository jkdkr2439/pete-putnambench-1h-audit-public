# putnam_1965_b1

View the integral as an expectation for independent uniform (X_i\in[0,1]). By the law of large numbers,
\[
\frac{X_1+\cdots+X_n}{n}\to\frac12
\]
in probability, hence the bounded continuous integrand converges in expectation to
\[
\cos^2(\pi/4)=\frac12.
\]
Thus the limit is (1/2).
