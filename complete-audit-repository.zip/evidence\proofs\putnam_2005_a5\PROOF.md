# putnam_2005_a5

Set (x=\tan t). The integral becomes
\[
\int_0^{\pi/4}\log(1+\tan t)dt
=\int_0^{\pi/4}\left(\tfrac12\log2+\log\cos(\tfrac\pi4-t)-\log\cos t\right)dt.
\]
The last two integrals cancel by reflection, leaving \(\pi\log2/8\).
