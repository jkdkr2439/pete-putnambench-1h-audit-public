# putnam_1992_a2

Since (1992) is even,
\[
C(-y-1)=\binom{-y-1}{1992}=\frac{(y+1)(y+2)\cdots(y+1992)}{1992!}=:G(y).
\]
Logarithmic differentiation gives
\[
G'(y)=G(y)\sum_{k=1}^{1992}\frac1{y+k},
\]
which is exactly the integrand. Therefore the integral is
\[
G(1)-G(0)=1993-1=1992.
\]
