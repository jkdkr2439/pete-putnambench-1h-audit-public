# putnam_2018_a1

Clearing denominators and factoring gives
\[
(3a-2018)(3b-2018)=2018^2.
\]
Both factors are positive. Conversely each positive divisor (d\mid2018^2) for which (d\equiv-2018\pmod3) gives the ordered solution
\[
a=\frac{d+2018}{3},\qquad b=\frac{2018^2/d+2018}{3}.
\]
Now (2018=2\cdot1009), with (1009\equiv1\pmod3), and a divisor is (d=2^i1009^j), (0\le i,j\le2). The required residue is (1\pmod3), so (i) must be even while (j) is arbitrary. Hence there are (2\cdot3=6) ordered pairs, parametrized by (i\in\{0,2\}), (j\in\{0,1,2\}) in the displayed formulas.
