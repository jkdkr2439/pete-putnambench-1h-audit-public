# putnam_1979_a2

Every (k\ge0) works: for (k>0), take (f(x)=k^{1/4}x^3), and for (k=0), take (f=0). If (k<0), the equation makes (f\circ f) strictly decreasing, so (f) is injective and continuous, hence strictly monotone. But the self-composition of a monotone function (whether increasing or decreasing) is increasing, a contradiction. Thus precisely (k\in[0,\infty)) are possible.
