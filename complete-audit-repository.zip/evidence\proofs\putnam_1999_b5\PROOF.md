# putnam_1999_b5

Let (c_j=\cos(j\theta)), (s_j=\sin(j\theta)). Then (A=cc^T-ss^T). The root-of-unity sums give (c\perp s) and \(\|c\|^2=\|s\|^2=n/2\) for (n\ge3). Thus (A) has eigenvalues (n/2,-n/2), and (0) with multiplicity (n-2). Consequently
\[
\det(I+A)=(1+n/2)(1-n/2)=1-\frac{n^2}{4}.
\]
