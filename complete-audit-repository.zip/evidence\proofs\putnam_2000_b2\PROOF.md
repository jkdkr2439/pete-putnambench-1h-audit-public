# putnam_2000_b2

Let (d=\gcd(m,n)). Since
\[
\frac dn\binom nm=\frac dm\binom{n-1}{m-1},
\]
it suffices to prove (m/d\mid\binom{n-1}{m-1}). For every prime (p), Legendre's formula (or the carry form of Kummer's theorem) gives
\[
v_p\binom{n-1}{m-1}\ge \max(0,v_p(m)-v_p(n))=v_p(m/d).
\]
Thus the divisibility holds prime by prime, and the expression is an integer.
