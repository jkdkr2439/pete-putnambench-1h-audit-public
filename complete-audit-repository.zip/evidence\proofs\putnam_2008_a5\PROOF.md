# putnam_2008_a5

Identify the plane with \(\mathbb C\) and put (h=f+ig). After a translation and rotation, the regular polygon condition says
\[
h(k)=c+R\zeta^k\qquad(k=1,\ldots,n),
\]
where (R\ne0) and ζ is a primitive (n)-th root of unity. If both (f,g) had degree at most (n-2), so would (h), and its ((n-1))-st forward difference on these (n) consecutive integers would be zero. But the displayed values have forward difference
\[
R\zeta(\zeta-1)^{n-1}\ne0.
\]
This contradiction shows that at least one of (f,g) has degree at least (n-1).
