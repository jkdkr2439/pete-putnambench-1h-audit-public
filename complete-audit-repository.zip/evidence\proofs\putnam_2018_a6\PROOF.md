# putnam_2018_a6

Translate (A) to the origin and write (u=B-A,v=C-A,w=D-A). All pairwise dot products among (u,v,w) are rational, because (2u\cdot v=|u|^2+|v|^2-|u-v|^2), and similarly. Since (A,B,C) are noncollinear, (u,v) are a basis; write (w=\alpha u+\beta v). Solving using dot products and the nonsingular rational Gram matrix of (u,v) shows \(alpha,eta\in\mathbb Q\). Noncollinearity of (A,B,D) gives \(eta\ne0\), and
\[
\frac{[ABC]}{[ABD]}=\frac{|\det(u,v)|}{|\det(u,w)|}=\frac1{|\beta|}\in\mathbb Q.
\]
