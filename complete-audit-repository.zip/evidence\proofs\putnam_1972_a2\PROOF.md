# putnam_1972_a2

The first law makes every left translation injective. We have
\[
x\cdot(x\cdot y)=y.
\]
Applying the second law with the pair (x,x\cdot y) gives
\[
y\cdot(x\cdot y)=x.
\]
The first law also gives (y\cdot(y\cdot x)=x). Injectivity of left multiplication by (y) now yields (x\cdot y=y\cdot x).

Associativity need not hold: on \(\mathbb R\), define (x\cdot y=-x-y). Both stated laws hold and the operation is commutative, but, for example, ((0\cdot0)\cdot1=-1\ne1=0\cdot(0\cdot1)).
