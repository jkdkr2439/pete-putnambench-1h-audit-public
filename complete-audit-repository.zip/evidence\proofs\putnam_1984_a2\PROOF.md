# putnam_1984_a2

Put (r_k=(2/3)^k). The (k)-th summand simplifies to
\[
\frac{r_k}{3(1-r_k)(1-r_{k+1})}
=\frac1{1-r_k}-\frac1{1-r_{k+1}}.
\]
The series telescopes, and its sum is
\[
\frac1{1-2/3}-1=2.
\]
