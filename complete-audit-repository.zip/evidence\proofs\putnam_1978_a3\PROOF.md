# putnam_1978_a3

The polynomial is reciprocal of degree six. Splitting at (1) and substituting (x\mapsto1/x) in the tail gives
\[
I_k=\int_0^1\frac{x^k+x^{4-k}}{p(x)}dx.
\]
Thus (I_1=I_3), while
\[
I_1-I_2=\int_0^1\frac{x(x-1)^2}{p(x)}dx>0,
\]
and
\[
I_4-I_2=\int_0^1\frac{(1-x^2)^2}{p(x)}dx>0.
\]
Hence (I_2) is uniquely smallest.
