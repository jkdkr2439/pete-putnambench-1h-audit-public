# putnam_1966_b5

Choose a point (O) not lying on any line through two of the given points, and order the points by polar angle about (O). Join consecutive points cyclically. If two nonadjacent edges crossed, their four endpoints would occur in interlacing angular order about (O), but straight segments with interlacing angular endpoints separate (O) inconsistently; equivalently, each edge lies in its angular wedge and nonadjacent wedges have disjoint interiors. Thus the cyclic joining is a simple closed polygon with precisely the prescribed vertex set.
