# putnam_1977_a1

## Claim

The constant is (k=-7/8).

## Proof

Let the line containing the four distinct points be (y=mx+b).  Their four distinct (x)-coordinates are roots of
\[
2x^4+7x^3+3x-5=mx+b,
\]
or
\[
2x^4+7x^3+(3-m)x-(5+b)=0.
\]
This is a quartic and already has four distinct real roots, namely those four coordinates, so these are all its roots.  By Vieta's formula their sum is
\[
-\frac{7}{2}.
\]
Consequently their average is
\[
\frac14\left(-\frac72\right)=-\frac78,
\]
independent of the line.
