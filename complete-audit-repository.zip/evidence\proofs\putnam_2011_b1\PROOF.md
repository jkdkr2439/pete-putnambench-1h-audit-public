# putnam_2011_b1

For a positive integer (N), choose
\[
m=k^2(N+1),\qquad n=h^2N.
\]
Then
\[
|h\sqrt m-k\sqrt n|=hk(\sqrt{N+1}-\sqrt N)=\frac{hk}{\sqrt{N+1}+\sqrt N}.
\]
These positive quantities decrease to (0). Choose (N) so large that the displayed quantity δ is less than ε. There is then a positive integer (L) with
\[
\epsilon<L\delta<2\epsilon,
\]
because the interval ((\epsilon/\delta,2\epsilon/\delta)) has length greater than (1). Replacing (m,n) by (L^2m,L^2n) multiplies the difference by (L), giving the desired pair.
