# putnam_2001_a3

Any integral factorization can be paired into two monic quadratics:
\[
(x^2+ax+b)(x^2-ax+d).
\]
The vanishing linear coefficient gives (a(d-b)=0). If (a=0), then (b,d) are integral roots of a quadratic whose discriminant is (32m); this is a square exactly when (m=2s^2) for an integer (s\ge0). If (b=d), comparison with the constant term gives (b=\pm(m-2)). The positive sign yields (a^2=4m), so (m=s^2); the negative sign would require (a^2=8), impossible in integers. Conversely these coefficient choices explicitly factor (P_m). Thus exactly the nonnegative integers (m) that are a square or twice a square work.
