# putnam_1971_a1

Classify a lattice point by the parities of its three coordinates. There are only (2^3=8) classes, so among nine points two distinct points (P,Q) have the same coordinatewise parity. Their midpoint ((P+Q)/2) is therefore a lattice point. Because (P\ne Q), this midpoint lies strictly inside the segment joining them.
