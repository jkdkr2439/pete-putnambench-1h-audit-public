# putnam_2006_a1

In cylindrical coordinates ρ=(\sqrt{x^2+y^2}), both sides are nonnegative, so the inequality is equivalent to
\[
\rho^2+z^2+8\le6\rho,
\]
or
\[
(\rho-3)^2+z^2\le1.
\]
This is the solid torus with major radius (3) and minor radius (1). By Pappus's centroid theorem (or direct cylindrical integration), its volume is
\[
(\pi\cdot1^2)(2\pi\cdot3)=6\pi^2.
\]
