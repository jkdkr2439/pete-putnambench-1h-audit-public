# putnam_2004_b2

In (m+n) Bernoulli trials with success probability (m/(m+n)), the probability of exactly (m) successes is strictly less than (1):
\[
\binom{m+n}{m}\left(\frac{m}{m+n}\right)^m\left(\frac{n}{m+n}\right)^n<1.
\]
Rearranging this strict inequality gives precisely
\[
\frac{(m+n)!}{(m+n)^{m+n}}<\frac{m!}{m^m}\frac{n!}{n^n}.
\]
