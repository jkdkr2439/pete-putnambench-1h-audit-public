# putnam_1977_b1

Put (q_n=n^2-n+1). Then
\[
\frac{n^3-1}{n^3+1}=\frac{n-1}{n+1}\frac{q_{n+1}}{q_n}.
\]
Consequently
\[
\prod_{n=2}^N\frac{n^3-1}{n^3+1}
=\frac{2}{N(N+1)}\frac{N^2+N+1}{3}.
\]
Letting (N\to\infty) gives (2/3).
