# putnam_2013_b1

Put (d(n)=c(n)c(n+2)). For (m\ge1), the recurrences give
\[
d(2m)=c(m)c(m+1),\qquad d(2m+1)=-c(m)c(m+1).
\]
Thus (d(2m)+d(2m+1)=0). In the sum from (1) through (2013), every term from (2) onward cancels in such a pair, leaving
\[
d(1)=c(1)c(3)=1\cdot(-1)=-1.
\]
