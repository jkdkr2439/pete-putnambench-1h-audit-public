# putnam_1980_b3

Iteration gives
\[
u_n=2^n\left(a-\sum_{j=0}^{n-1}\frac{j^2}{2^{j+1}}\right).
\]
The partial sums increase to \(\sum_{j\ge0}j^2/2^{j+1}=3\). Hence all (u_n>0) exactly when (a\ge3): for (a<3) a partial sum eventually exceeds (a), while for (a=3) every finite tail is strictly positive. The answer is ([3,\infty)).
