# putnam_2011_a4

Reduce row entries modulo (2). Their Gram matrix must be the matrix with zero diagonal and one off diagonal, whose determinant is \((-1)^{n-1}(n-1)\). If (n) is even this determinant is (1) in \(\mathbb F_2\), so the row matrix would be invertible; but every even-weight row is orthogonal to the all-ones vector, impossible.

For odd (n=2h+1), take the first (n-1) rows to be (e_i+e_n), and the last row to be (e_1+\cdots+e_{n-1}). Each has even self-dot-product and every two distinct rows have odd dot product. Hence precisely the odd positive integers (n) work.
