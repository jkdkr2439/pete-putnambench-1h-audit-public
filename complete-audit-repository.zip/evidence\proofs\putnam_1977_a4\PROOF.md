# putnam_1977_a4

For (y=x^{2^n}),
\[
\frac{y}{1-y^2}=\frac1{1-y}-\frac1{1-y^2}.
\]
Thus the partial sum through (n=N) telescopes to
\[
\frac1{1-x}-\frac1{1-x^{2^{N+1}}}.
\]
Since (0<x<1), the last term tends to (1), leaving
\[
\frac1{1-x}-1=\frac{x}{1-x}.
\]
