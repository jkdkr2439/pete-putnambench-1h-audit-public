# putnam_2010_a2

The cases (n=1,2) give (f(x+1)=f(x)+f'(x)) and (f(x+2)=f(x)+2f'(x)). Iterating the first and comparing with the second yields (f'(x+1)=f'(x)). Let (g=f'). The first identity and the fundamental theorem give
\[
g(x)=f(x+1)-f(x)=\int_x^{x+1}g(t)dt.
\]
Because (g) is 1-periodic, the right side is its constant mean, so (g) is constant. Hence (f(x)=cx+d). Every such function directly satisfies all the equations, and these are all solutions.
