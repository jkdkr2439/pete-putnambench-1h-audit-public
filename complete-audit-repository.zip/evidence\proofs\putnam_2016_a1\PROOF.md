# putnam_2016_a1

Expanding an integer polynomial about an integer (k) shows that the coefficient of ((x-k)^j) is an integer; hence (p^{(j)}(k)) is always divisible by (j!). Conversely (p(x)=x^j), evaluated at (k=0), gives (p^{(j)}(0)=j!), so the condition is exactly (2016\mid j!). Since
\[
2016=2^5\cdot3^2\cdot7,
\]
(7!) has only (v_2(7!)=4), while (8!) contains all these factors. The smallest (j) is therefore (8).
