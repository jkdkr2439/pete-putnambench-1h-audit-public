# putnam_1964_a2

There are no such functions. Indeed the three moment equations imply
\[
\int_0^1(x-\alpha)^2f(x)dx=\alpha^2-2\alpha^2+\alpha^2=0.
\]
But (f) is continuous and strictly positive, while ((x-α)^2) is positive except at at most one point, so the integral is strictly positive, a contradiction.
