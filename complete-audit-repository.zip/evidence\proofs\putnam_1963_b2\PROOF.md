# putnam_1963_b2

Yes. The ratio \(\log2/\log3\) is irrational, since a rational ratio would give (2^q=3^p) for positive integers (p,q). Therefore the additive group \(\{m\log2+n\log3:m,n\in\mathbb Z\}\) is dense in \(\mathbb R\) (fractional multiples of an irrational number are dense modulo one). Exponentiation, a continuous map onto ((0,\infty)), shows that \(\{2^m3^n\}\) is dense in (P).
