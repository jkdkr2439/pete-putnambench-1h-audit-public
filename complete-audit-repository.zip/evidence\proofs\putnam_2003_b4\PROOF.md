# putnam_2003_b4

Put (s=r_1+r_2), (t=r_3+r_4), (u=r_1r_2), and (v=r_3r_4). Vieta gives (s+t\in\mathbb Q), so (t\in\mathbb Q). The coefficients of (z^2) and (z) give
\[
u+v+st\in\mathbb Q,qquad sv+tu\in\mathbb Q.
\]
Thus (u+v) and (tu+sv) are rational. Since (s\ne t), this nonsingular pair of linear equations in (u,v) has rational coefficients and rational right sides. Hence (u,v\in\mathbb Q), in particular (r_1r_2=u\in\mathbb Q).
