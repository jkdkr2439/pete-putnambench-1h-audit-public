# putnam_1970_a4

Let (y_n=x_n-x_{n-1}) and ε_n=(x_n-x_{n-2}	o0). Then (y_n=-y_{n-1}+ε_n), so iteration gives
\[
y_n=(-1)^ny_0+\sum_{k=1}^n(-1)^{n-k}\epsilon_k.
\]
Because ε_k→0, its partial absolute sums are (o(n)). Hence |(y_n)|/n→0, proving \((x_n-x_{n-1})/n\to0\).
