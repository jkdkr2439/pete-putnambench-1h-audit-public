# putnam_1984_b1

Since (f(n+2)=f(n+1)+(n+2)!) and ((n+1)!=f(n+1)-f(n)),
\[
f(n+2)=f(n+1)+(n+2)(f(n+1)-f(n))
=(n+3)f(n+1)-(n+2)f(n).
\]
Thus (P(x)=x+3) and (Q(x)=-(x+2)).
