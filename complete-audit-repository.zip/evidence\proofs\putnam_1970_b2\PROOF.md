# putnam_1970_b2

Both sides are linear in (H), so it suffices to check (H(t)=1,t,t^2,t^3). Odd monomials have average zero on both sides. For (1), both averages are (1); for (t^2), the interval average is (T^2/3), equal to the average of the two values at \(\pm T/\sqrt3\). Thus the identity holds for every polynomial of degree at most three.
