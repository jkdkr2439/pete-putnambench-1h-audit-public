# putnam_2015_a2

An odd prime factor is (181). In \(\mathbb F_{181}\), (33^2=3), so the recurrence solution is
\[
a_n=\frac{35^n+150^n}{2},
\]
where (35=2+33), (150=2-33), and their product is (1). Fermat reduces (2015\) modulo (180) to (35). Repeated squaring gives
\[
35^{35}\equiv162,qquad150^{35}\equiv19\pmod{181},
\]
so their sum is (0) modulo (181). Hence (181\mid a_{2015}).
