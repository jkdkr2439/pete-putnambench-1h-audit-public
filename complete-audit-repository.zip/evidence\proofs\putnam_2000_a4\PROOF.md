# putnam_2000_a4

On [1,B] write \(\sin x^2=-(2x)^{-1}(\cos x^2)'\) and integrate by parts. The boundary term has a limit, while the remaining terms are dominated by a constant times \(x^{-2}\) (differentiate \(\sin x/(2x)\)). Hence the tail converges absolutely after integration by parts. The integral on [0,1] is ordinary, so the improper integral converges.
