# putnam_2021_a2

Taking logarithms and differentiating at (r=0) gives
\[
\log g(x)=(x+1)\log(x+1)-x\log x.
\]
Therefore
\[
\log\frac{g(x)}x=(x+1)\log(1+1/x)\to1,
\]
so the required limit is (e).
