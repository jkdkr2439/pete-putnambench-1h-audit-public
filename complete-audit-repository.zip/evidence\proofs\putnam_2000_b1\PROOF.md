# putnam_2000_b1

Reduce each triple modulo (2), obtaining a nonzero vector (v_j\in\mathbb F_2^3). Choose (w=(r,s,t)) uniformly among the seven nonzero vectors. For each fixed nonzero (v_j), exactly four of those seven vectors satisfy (w\cdot v_j=1). Thus the expected number of odd dot products is (4N/7). Some choice of (w), represented by integers (r,s,t), attains at least its expectation.
