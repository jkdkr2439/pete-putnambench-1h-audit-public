# putnam_1972_a5

Suppose (n>1) divides (2^n-1), and let (p) be the least prime divisor of (n). The multiplicative order (d) of (2) modulo (p) divides both (n) and (p-1). Any prime divisor of \(\gcd(n,p-1)\) would divide (n), hence be at least (p), but also divide (p-1), impossible. Thus (d=1), which says (2\equiv1\pmod p), a contradiction.
