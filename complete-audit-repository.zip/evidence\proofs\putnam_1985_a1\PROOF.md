# putnam_1985_a1

For each element of \(\{1,\ldots,10\}\), record the subcollection of the three ordered sets containing it. The union condition excludes the empty membership pattern, and the triple-intersection condition excludes the full pattern. Thus each element independently has (2^3-2=6) choices. The number of ordered triples is
\[
6^{10}=2^{10}3^{10},
\]
so ((a,b,c,d)=(10,10,0,0)).
