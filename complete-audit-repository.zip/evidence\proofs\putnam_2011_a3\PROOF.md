# putnam_2011_a3

Write (b=\pi/2). Endpoint Laplace asymptotics give
\[
\int_0^b x^r\sin x\,dx\sim\frac{b^{r+1}}r,
\qquad
\int_0^b x^r\cos x\,dx\sim\frac{b^{r+2}}{r^2},
\]
the second using \(\cos(b-u)\sim u\). Their ratio is asymptotic to (r/b). Thus one may take
\[
c=-1,qquad L=\frac1b=\frac2\pi.
\]
