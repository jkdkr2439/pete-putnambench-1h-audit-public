# putnam_2004_a6

Work in (L^2([0,1]^2)). Let (P_xf=\int_0^1f(x,y)dy), (P_yf=\int_0^1f(x,y)dx), and (P_0f=\iint f), viewed as functions constant in the omitted variables. The four components
\[
P_0f,quad P_xf-P_0f,quad P_yf-P_0f,quad f-P_xf-P_yf+P_0f
\]
are mutually orthogonal. Hence
\[
\|P_xf\|^2+\|P_yf\|^2=2\|P_0f\|^2+\|P_xf-P_0f\|^2+\|P_yf-P_0f\|^2
\le \|P_0f\|^2+\|f\|^2,
\]
which is exactly the stated inequality.
