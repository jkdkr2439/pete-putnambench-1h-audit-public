# putnam_1969_b1

Write (n=\prod p^e\). Since (n\equiv2\pmod3), some prime (p\equiv2\pmod3) has odd exponent; its factor (1+p+\cdots+p^e) in σ((n)) is divisible by (3).

Also (n\equiv7\pmod8). For every odd exponent (e), LTE gives
\[
v_2(1+p+\cdots+p^e)=v_2(p+1)+v_2(e+1)-1.
\]
The odd-exponent prime-power residues whose product is (7\pmod8) either include a residue (7), contributing at least three factors of (2), or include residues (3) and (5), contributing at least two and one; extra factors cannot reduce the valuation. Hence (8\mid\sigma(n)). Together with (3\mid\sigma(n)), this gives (24\mid\sigma(n)).
