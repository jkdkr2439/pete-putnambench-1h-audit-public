# putnam_1988_a1

For fixed (y\in[-1,1]), the inequality \(|x|-|y|\le1\) is equivalent to \(|x|\le1+|y|\), giving a horizontal width (2(1+|y|)). Hence
\[
[R]=\int_{-1}^1 2(1+|y|)\,dy=6.
\]
