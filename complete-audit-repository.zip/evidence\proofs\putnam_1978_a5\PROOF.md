# putnam_1978_a5

The function
\[
\phi(x)=\log\frac{\sin x}{x}
\]
is concave on ((0,\pi)), because
\[
\phi''(x)=\frac1{x^2}-\frac1{\sin^2x}<0.
\]
Jensen's inequality therefore gives
\[
\sum_{i=1}^n\log\frac{\sin a_i}{a_i}\le n\log\frac{\sin\mu}{\mu}.
\]
Exponentiating proves the desired product inequality.
