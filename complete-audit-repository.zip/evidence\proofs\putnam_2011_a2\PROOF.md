# DRAFT UNCOUNTED — putnam_2011_a2

This draft was never hash-locked. Audit found that the argument forcing the terminal ratio to zero was incomplete.

Let (P_n=a_1\cdots a_n). Dividing (b_n=a_nb_{n-1}-2) by (P_n) gives
\[
\frac{b_n}{P_n}=\frac{b_{n-1}}{P_{n-1}}-\frac2{P_n}.
\]
Thus (2\sum_{n=2}^N1/P_n=1-b_N/P_N). The nonnegative ratios decrease to a limit ℓ. If ℓ>0, boundedness of (b_N) bounds (P_N); the recurrence and positivity then force the successive factors toward (1), while (b_n=a_nb_{n-1}-2) forces a fixed downward drift, a contradiction. Hence ℓ=0. Including (1/P_1=1),
\[
S=1+\frac12=\frac32.
\]
