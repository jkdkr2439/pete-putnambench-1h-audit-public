# putnam_2020_b1

Write ε((k))=((-1)^{d(k)}). The generating identity
\[
\sum_{k=0}^{2047}\epsilon(k)e^{kt}=\prod_{j=0}^{10}(1-e^{2^jt})
\]
has a zero of order (11) at (t=0). Its third derivative there therefore gives
\[
\sum_{k=0}^{2047}\epsilon(k)k^3=0.
\]
Consequently the required sum is the negative of the tail from (2021) to (2047). Reducing cubes modulo (2020), that signed tail is
\[
1+8-27-64+125+216-343+512-729-1000+1331-1728
\]
\[
{}+177+724-1355+56-873-1792+799+1940-1181-548+47-1704+1485+1416-1503
\equiv30\pmod{2020}.
\]
Hence
\[
S\equiv-30\equiv1990\pmod{2020}.
\]
