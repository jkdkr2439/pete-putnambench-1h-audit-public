# putnam_2006_b2

Order the (n) given numbers arbitrarily and consider the (n+1) prefix sums (s_0=0,s_j=x_1+\cdots+x_j) modulo (1). Arrange their fractional parts cyclically on the unit circle. Some cyclic gap is at most (1/(n+1)). The difference of its endpoints modulo (1) is the sum of a nonempty consecutive block of the (x_i)'s plus an integer (m), with absolute representative at most (1/(n+1)). Taking that block as (S) proves the claim.
