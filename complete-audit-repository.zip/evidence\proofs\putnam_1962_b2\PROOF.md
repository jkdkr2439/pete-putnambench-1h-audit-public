# putnam_1962_b2

Enumerate the rationals as (q_1,q_2,\ldots), and define
\[
f(a)=\{n\in\mathbb N:q_n<a\}.
\]
If (a<b), inclusion (f(a)\subseteq f(b)) is immediate, and it is strict because density of the rationals supplies some (q_n\in(a,b)). Thus the required function exists.
