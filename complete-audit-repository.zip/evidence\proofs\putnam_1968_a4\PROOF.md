# putnam_1968_a4

For unit vectors (v_1,\ldots,v_n\),
\[
\sum_{i<j}\|v_i-v_j\|^2
=n\sum_i\|v_i\|^2-\left\|\sum_i v_i\right\|^2
=n^2-\left\|\sum_i v_i\right\|^2\le n^2.
\]
