# putnam_1991_a2

Subtracting the given mixed identity from (A^3=B^3) yields
\[
A^2(A-B)=B^3-B^2A=-B^2(A-B).
\]
Hence
\[
(A^2+B^2)(A-B)=0.
\]
If (A^2+B^2) were invertible, this would force (A=B), contrary to the hypothesis. Therefore it cannot be invertible.
