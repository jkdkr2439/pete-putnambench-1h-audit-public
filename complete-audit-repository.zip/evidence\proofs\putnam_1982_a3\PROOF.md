# putnam_1982_a3

Let (F(a)=\int_0^\infty[\arctan(ax)-\arctan x],dx/x). Differentiation under the integral gives
\[
F'(a)=\int_0^\infty\frac{dx}{1+a^2x^2}=\frac\pi{2a}.
\]
Since (F(1)=0), integration from (1) to π yields
\[
F(\pi)=\frac\pi2\log\pi.
\]
