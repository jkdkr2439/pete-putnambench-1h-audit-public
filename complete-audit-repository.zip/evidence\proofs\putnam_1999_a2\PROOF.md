# putnam_1999_a2

A real polynomial nonnegative on all of \(\mathbb R\) has positive leading coefficient and every real root has even multiplicity. Factor it over \(\mathbb C\): after extracting a square from the real roots, every conjugate pair contributes
\[
(x-z)(x-\bar z)=(x-\Re z)^2+(\Im z)^2.
\]
The product of two sums of two squares is again a sum of two squares by the Brahmagupta identity. Absorbing the positive leading constant as a square proves that (p) is a sum of two polynomial squares (and hence has the requested form).
