# putnam_1979_b3

In odd characteristic a quadratic is irreducible exactly when its discriminant is a nonsquare. As (d) ranges over (F), the discriminant (b^2-4(c+d)) ranges bijectively over (F). Exactly ((n-1)/2) elements of the finite field are nonzero nonsquares. Hence that many choices of (d) give an irreducible quadratic.
