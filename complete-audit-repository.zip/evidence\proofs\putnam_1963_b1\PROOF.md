# putnam_1963_b1

Modulo (x^2-x+a), write (x^j=A_j(a)x+B_j(a)). From (x^2=x-a),
\[
A_j=A_{j-1}-aA_{j-2},\qquad B_j=B_{j-1}-aB_{j-2}.
\]
Iteration to (j=13) shows that the coefficient of (x) in the remainder of (x^{13}+x+90) is
\[
P(a)=a^6-21a^5+70a^4-84a^3+45a^2-11a+2.
\]
If an integer (a) works, the monic polynomial (P) vanishes at (a), so the integer-root theorem leaves (a\in\{\pm1,\pm2\}). Direct substitution leaves only (a=2). The same recurrence gives the constant remainder
\[
6a^6-35a^5+56a^4-36a^3+10a^2-a+90,
\]
which also vanishes at (a=2). Therefore the unique answer is (2).
