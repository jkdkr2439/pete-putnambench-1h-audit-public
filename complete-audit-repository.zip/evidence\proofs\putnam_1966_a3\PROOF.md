# putnam_1966_a3

The sequence is positive and decreasing, and its limit (L) satisfies (L=L(1-L)); hence (L=0). Moreover
\[
\frac1{x_{n+1}}-\frac1{x_n}=\frac1{1-x_n}\to1.
\]
By Stolz--Cesàro, \((1/x_n)/n\to1\), which is equivalent to (nx_n\to1).
