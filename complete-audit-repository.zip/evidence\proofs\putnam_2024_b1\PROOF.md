# putnam_2024_b1

Let the selected column in row (i) be π(i). Summing the selected entries in two ways gives
\[
n(n+1)-nk=1+\cdots+n=\frac{n(n+1)}2,
\]
so (k=(n+1)/2); in particular (n) must be odd.

Conversely write (n=2h+1) and (k=h+1). Choose the cyclic-shift permutation
\[
\pi(i)=\begin{cases}i+h,&1\le i\le h+1,\\i-h-1,&h+2\le i\le2h+1.\end{cases}
\]
The sums (i+\pi(i)) are respectively the alternating integers
\[
h+2,h+4,\ldots,3h+2
\]
and
\[
h+3,h+5,\ldots,3h+1.
\]
Together they are every integer from (h+2) through (3h+2). Subtracting (k=h+1) produces exactly (1,\ldots,n). Thus the answer is precisely: (n) odd and (k=(n+1)/2).
