# putnam_2017_b1

For fixed (P) and nonzero λ, the possible points (A_2=P+\lambda(A_1-P)), as (A_1) ranges over (L_1), form a line homothetic to and hence parallel to (L_1). If (L_1) intersects (L_2), the two original lines are nonparallel, so this homothetic line also intersects (L_2), supplying the required points.

Conversely, if the distinct lines are parallel, their signed offsets from (P) are two nonzero distinct numbers (because (P) lies on neither). Homothety by λ sends the first offset to λ times itself, so its image equals (L_2) for at most one nonzero λ. Choosing any other nonzero λ makes the parallel lines disjoint, contradicting the stated property.
