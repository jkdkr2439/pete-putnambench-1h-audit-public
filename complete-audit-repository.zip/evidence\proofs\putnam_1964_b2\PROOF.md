# putnam_1964_b2

Complementation pairs all subsets of (S). An intersecting family contains at most one member of each complementary pair, hence at most half of all subsets. If (A\notin P), maximality supplies (B\in P) disjoint from (A), so (B\subseteq A^c). If also (A^c\notin P), maximality supplies (C\in P) disjoint from (A^c), so (C\subseteq A); then (B,C) are disjoint, impossible. Thus (A^c\in P). Exactly one set from every complementary pair lies in (P), so (P) has (2^{|S|-1}) members.
