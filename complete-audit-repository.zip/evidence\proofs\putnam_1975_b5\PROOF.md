# putnam_1975_b5

From (e^x=\sum_{k\ge0}x^k/k!), repeated application of (xD) gives
\[
f_n(x)=\sum_{k\ge0}\frac{k^n x^k}{k!}.
\]
All terms are nonnegative at (x=1), so Tonelli's theorem permits reversal:
\[
\sum_{n\ge0}\frac{f_n(1)}{n!}
=\sum_{k\ge0}\frac1{k!}\sum_{n\ge0}\frac{k^n}{n!}
=\sum_{k\ge0}\frac{e^k}{k!}=e^e.
\]
