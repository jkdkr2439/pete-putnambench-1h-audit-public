# putnam_1990_a5

Yes. Associativity gives
\[
BABA=B(ABAB)A=0.
\]
