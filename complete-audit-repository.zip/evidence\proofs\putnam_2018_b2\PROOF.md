# putnam_2018_b2

Multiplication gives
\[
(1-z)f_n(z)=n-(z+z^2+\cdots+z^n).
\]
If (f_n(z)=0) with |(z)|≤1 and (z\ne1), then (z+\cdots+z^n=n). Equality in the triangle inequality forces every (z^k) to have modulus (1) and the same positive argument, hence (z=1), a contradiction. At (z=1), (f_n(1)=n(n+1)/2\ne0). Thus there are no roots in the closed unit disk.
