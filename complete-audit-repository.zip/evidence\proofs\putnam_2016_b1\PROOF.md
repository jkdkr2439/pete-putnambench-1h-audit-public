# putnam_2016_b1

For (x>0), (e^x-x>1), so every (x_n>0). Also (e^x-x<e^x), hence (0<x_{n+1}<x_n); the sequence tends to some (L\ge0). Passing to the recurrence gives (e^L=e^L-L), so (L=0). Exponentiating the recurrence yields
\[
x_n=e^{x_n}-e^{x_{n+1}}.
\]
Thus the partial sums telescope to (e^{x_0}-e^{x_{N+1}}), which tends to (e-1). In particular the series converges and has sum (e-1).
