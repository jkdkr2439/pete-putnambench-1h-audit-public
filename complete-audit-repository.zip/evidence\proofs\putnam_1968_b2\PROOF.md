# putnam_1968_b2

Fix (g\in G). Both (A) and (gA^{-1}=\{ga^{-1}:a\in A\}) contain more than half the elements of (G), so they intersect. Write a common element as (b=ga^{-1}), with (a,b\in A). Then (g=ba), a product of two elements of (A).
