# putnam_1971_a6

First (c\ge0), since for (c<0) the integer (2^c) lies strictly between (0) and (1). Suppose (c\ge0) is not an integer and put (r=\lfloor c\rfloor+1). The (r)-th forward difference
\[
\Delta^r n^c=\sum_{j=0}^r(-1)^{r-j}\binom rj(n+j)^c
\]
is an integer for every (n). Standard finite-difference asymptotics give
\[
\Delta^r n^c\sim c(c-1)\cdots(c-r+1)n^{c-r}.
\]
The coefficient is nonzero and (c-r<0), so these integers are nonzero but tend to (0), impossible. Therefore (c) is a nonnegative integer, and such (c) plainly work.
