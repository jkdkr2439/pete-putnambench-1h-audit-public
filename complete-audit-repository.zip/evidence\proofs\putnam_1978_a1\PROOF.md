# putnam_1978_a1

## Claim

Every 20-element subset of (S) contains two distinct elements summing to (104).

## Proof

Apart from (1), the elements of (S) are partitioned under the involution (s\mapsto104-s) into the sixteen two-element pairs
\[
\{4,100\},\{7,97\},\ldots,\{49,55\}
\]
and the singleton ({52}).  (The singleton cannot itself supply two distinct elements.)

If a subset contains no two distinct elements with sum (104), it contains at most one member of each of the sixteen pairs.  It may additionally contain (1) and (52).  Its size is therefore at most
\[
16+1+1=18.
\]
Since (20>18), every 20-element subset (T) must contain both members of one of the pairs, and those two distinct elements sum to (104).
