# putnam_2005_b1

Put (x=\lfloor a\rfloor) and (y=\lfloor2a\rfloor). Writing (a=x+u) with (0\le u<1) shows (y=2x+\lfloor2u\rfloor), so (y-2x\in\{0,1\}). Hence the nonzero polynomial
\[
P(x,y)=(y-2x)(y-2x-1)
\]
vanishes for every required pair.
