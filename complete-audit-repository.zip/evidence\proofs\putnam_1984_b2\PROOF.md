# putnam_1984_b2

The first point \((u,\sqrt{2-u^2})\) has norm \(\sqrt2\). The second point ((v,9/v)) has norm at least \(\sqrt{2v(9/v)}=3\sqrt2\). Their distance is therefore at least (2\sqrt2), so the squared distance is at least (8). Equality occurs when both points lie on the ray (y=x), namely at (u=1,v=3). The minimum is (8).
