# putnam_2008_b3

Center the unit 4-cube at the origin. A circle of radius (r) lies in some affine two-plane; translating its center to the cube center can only improve its clearance from opposite facets. If (P) is the orthogonal projection onto its direction plane, containment requires
\[
r\|Pe_i\|\le\frac12quad(i=1,\ldots,4).
\]
But \(\sum_i\|Pe_i\|^2=\operatorname{tr}P=2\), so some norm is at least (1/\sqrt2), giving (r\le1/\sqrt2). Equality is achieved by a plane whose projection has all four diagonal entries (1/2), for example the span of \((1,1,1,1)/2\) and \((1,-1,1,-1)/2\). Thus the maximum radius is (1/\sqrt2).
