# putnam_1986_a3

For (n\ge0), the tangent subtraction formula gives
\[
\arccot(n^2+n+1)=\arctan(n+1)-\arctan n.
\]
(Both sides lie in the required interval.) The series telescopes to
\[
\lim_{N\to\infty}\arctan(N+1)-\arctan0=\frac\pi2.
\]
