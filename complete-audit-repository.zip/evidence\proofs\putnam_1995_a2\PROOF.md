# putnam_1995_a2

Rationalizing the inner differences and expanding at infinity gives
\[
\sqrt{\sqrt{x+a}-\sqrt x}=\sqrt{\frac a2},x^{-1/4}+O(x^{-5/4}),
\]
and
\[
\sqrt{\sqrt x-\sqrt{x-b}}=\sqrt{\frac b2},x^{-1/4}+O(x^{-5/4}).
\]
Thus if (a\ne b), the integrand has a nonzero constant multiple of (x^{-1/4}) and the improper integral diverges. If (a=b), the leading terms cancel and the remainder is (O(x^{-5/4})), which is integrable; the integrand is continuous at the finite lower endpoint. Hence convergence occurs exactly for (a=b>0).
