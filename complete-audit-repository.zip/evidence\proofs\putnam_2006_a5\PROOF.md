# putnam_2006_a5

Let (n=2h+1) and (T=\tan(n\theta)). The numbers (a_k) are the (n) roots of the numerator equation obtained from \(\tan(n\phi)=T\). In the resulting degree-(n) polynomial, the leading coefficient is ((-1)^h), the coefficient of (t^{n-1}) is (-T(-1)^h n), and the constant term is (-T). Vieta's formulas therefore give
\[
\sum a_k=nT,qquad \prod a_k=(-1)^hT.
\]
(Irrationality of \(\theta/\pi\) keeps the tangents and (T) finite and nonzero in the exceptional cases relevant to the quotient.) Hence
\[
\frac{\sum a_k}{\prod a_k}=(-1)^h n=(-1)^{(n-1)/2}n,
\]
an integer.
