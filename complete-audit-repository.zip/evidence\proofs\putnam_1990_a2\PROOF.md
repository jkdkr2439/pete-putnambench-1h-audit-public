# putnam_1990_a2

Yes. Let (m=M^3) and choose (n_M) to be the nearest integer to \((M+\sqrt2)^3\). The mean value theorem for the cube-root function gives
\[
\left|\sqrt[3]{n_M}-(M+\sqrt2)\right|=O(M^{-2}),
\]
because the rounding error is at most (1/2). Since \(\sqrt[3]m=M\), the differences \(\sqrt[3]{n_M}-\sqrt[3]m\) tend to \(\sqrt2\).
