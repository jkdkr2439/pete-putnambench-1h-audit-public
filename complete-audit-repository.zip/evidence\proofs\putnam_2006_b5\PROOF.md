# putnam_2006_b5

Pointwise,
\[
x^2f(x)-xf(x)^2=-x\left(f(x)-\frac x2\right)^2+\frac{x^3}{4}\le\frac{x^3}{4}.
\]
Integration gives (I(f)-J(f)\le1/16), and equality is attained by the continuous function (f(x)=x/2). The maximum is (1/16).
