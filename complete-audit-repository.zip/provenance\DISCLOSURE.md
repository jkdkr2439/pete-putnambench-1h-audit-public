# Disclosure record

Included: paper source and PDF, final reports, corpus inventory metadata, run manifest, one-row-per-item outcomes, append-only event log, proof-lock ledger, and candidate proof files.

Excluded: sealed solution archive, decrypted references, credentials, framework repositories, Fieldmap source, internal maps, graph schemas, gates, rules, prompts, orchestration, and private chat transcripts.

No locked proof was rewritten for publication. Three explicitly uncounted drafts remain visibly marked as drafts and are not represented as locks.

