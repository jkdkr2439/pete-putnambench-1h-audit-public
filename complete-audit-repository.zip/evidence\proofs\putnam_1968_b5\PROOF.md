# putnam_1968_b5

Such a matrix over \(\mathbb F_p\) has characteristic polynomial (t^2-t=t(t-1)). It is therefore a rank-one projection: its image is a line (L), its kernel is a distinct line (K), and conversely each ordered pair of distinct lines determines one projection. There are (p+1) lines in \(\mathbb F_p^2\), and after choosing (L) there are (p) choices for (K). The number is (p(p+1)).
