# putnam_1992_a1

Condition (i) makes (f) injective. Comparing (i) with (ii), injectivity gives
\[
f(n+2)+2=f(n),
\]
so (f(n+2)=f(n)-2) for every integer (n). Since (f(0)=1), condition (i) also gives (f(1)=0). The recurrence now yields (f(n)=1-n) on both parity classes. Direct substitution verifies that this function satisfies all three conditions, proving uniqueness.
