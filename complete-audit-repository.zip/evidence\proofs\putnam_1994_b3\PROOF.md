# putnam_1994_b3

Since (f'-f>0), the positive function (e^{-x}f(x)) is strictly increasing. Fixing any (x_0), we get (f(x)>ce^x) for (x>x_0), with (c=e^{-x_0}f(x_0)>0). Hence (f(x)>e^{kx}) eventually for every (k\le1). If (k>1), choose (1<q<k) and (f(x)=e^{qx}); it satisfies (f'>f) but never eventually exceeds (e^{kx}). The set is ((-∞,1]).
