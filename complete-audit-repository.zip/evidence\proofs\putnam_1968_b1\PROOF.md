# Putnam 1968 B1 — candidate proof

For every outcome, the multiset `{X,Y}` contains exactly as many occurrences of `k` as the multiset `{min(X,Y),max(X,Y)}`. Hence pointwise

`1_{X=k}+1_{Y=k}=1_{min(X,Y)=k}+1_{max(X,Y)=k}`.

Taking expectations yields

`P(X=k)+P(Y=k)=P(min(X,Y)=k)+P(max(X,Y)=k)`.

Consequently

`P(min(X,Y)=k)=p_1+p_2-p_3`.

No independence assumption is used.

Status before grading: `PROOF_COMPLETE`.
