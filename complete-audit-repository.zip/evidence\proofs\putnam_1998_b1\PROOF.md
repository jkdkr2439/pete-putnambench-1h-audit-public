# putnam_1998_b1

Put (t=x+x^{-1}\ge2). Since (x^3+x^{-3}=t^3-3t) and (x^6+x^{-6}=(t^3-3t)^2-2), the expression simplifies to
\[
\frac{3t^2(2t^2-3)}{t(2t^2-3)}=3t.
\]
Its minimum is therefore (6), attained at (x=1).
