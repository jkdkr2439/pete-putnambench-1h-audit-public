# Pete PutnamBench one-hour pilot

Window: `2026-08-13T20:31:41.671254+00:00` to `2026-08-13T21:31:41.671254+00:00`.
Corpus: 673 informal statements at upstream commit `dfb0a47a1c1ec3a10f2a9acfdf41a2043920f33c`.

- Immutable natural-language proof candidates: 178
- Locked results matching sealed references: 100
- Manual self-audit passes where reference was empty: 72
- Audit gaps: 3
- Audit failures: 2
- Reference conflicts: 1
- Pre-run contaminated: 3
- Unlocked/unattempted: 492
- Proof hash mismatches: 0
- Append-only log-chain errors: 0
- Formal proof-assistant verified: 0/673

Result matching is not proof verification. Manual self-audit is not independent review. Skipped, contaminated, failed, conflicting, and non-formalized items receive no official formal credit.
